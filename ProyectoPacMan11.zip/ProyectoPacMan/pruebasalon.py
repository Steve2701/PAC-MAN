from tkinter import *

menu = None
puntuacion = 0

def subir():
    global puntuacion
    puntuacion += 1
    print(puntuacion)

def agarrar_nombre(username):
    nombre = username.get()
    with open('data.txt', 'a') as file:
        file.write(f'{puntuacion}-{nombre},')

def mostrar_ranking():
    try:
        with open('data.txt', 'r') as file:
            data = file.read().strip(',').split(',')
            top_scores = sorted(data, key=lambda x: int(x.split('-')[0]), reverse=True)

            menu = Tk()
            menu.title('Ranking')
            menu.geometry('400x400')

            for i, score in enumerate(top_scores[:5], start=1):
                Label(menu, text=f'{i}) {score}', font=('Arial Black', 14)).pack()

            Button(menu, text='Back', command=ventana).pack()
    except FileNotFoundError:
        pass

def ventana():
    global menu
    global puntuacion
    menu = Tk()
    menu.title('Agregar Puntaje')
    menu.geometry('400x200')

    username = Entry(menu, width=40)
    username.pack()

    Button(menu, text="+", command=subir).pack()
    Button(menu, text="Submit", command=lambda: agarrar_nombre(username)).pack()

    menu.mainloop()

ventana()
