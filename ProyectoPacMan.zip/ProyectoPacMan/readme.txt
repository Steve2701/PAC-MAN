Saludos.

Para la revisión del proyecto debe utilizarse la versión 3.11 de Python o superior.

Debe tener instalado en su computadora lo siguiente:
1- Python 3.11 o superior.
2- Pillow.
3- Natsort.
4- Pygame.

La ruta de git es la siguiente: https://github.com/Steve2701/PAC-MAN