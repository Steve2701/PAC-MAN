import tkinter
from tkinter import *
import tkinter as tk
from threading import Thread
from tkinter import PhotoImage,NW
from PIL import Image, ImageTk
import pygame as py
from pygame import mixer
import time
import sys
import math
import random

mixer.init()
#Colores
verde="#008F39"
navy = "#2B3467"
celeste = "#99B4D1"
celesteoscuro = "#296d98"
amarillo = "#FCFFE7"
rojo = "#EB455F"
gris = "#b5b5b5"
grisoscuro = "#666666"
azul = "#3E5F8A"
negro = "#000000"
blanco = "#FFFFFF"
azulclaro="#256d7b"
grisoscuro = "#666666"

#Fuentes
impact = "Impact"
arial="Arial"
timesnewroman="TimesNewRoman"

# Funcion para mostrar ventanas
def mostrar_ventana(ventana_a_mostrar):
    global ventana_actual
    usuario.delete(0, "end")
    canvasC1.delete("all")
    canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco)
    ventana_actual.withdraw()  # Oculta la ventana actual
    ventana_a_mostrar.deiconify()  # Muestra la nueva ventana
    ventana_actual = ventana_a_mostrar

def subir_foto(canvas):
    foto = Image.open("Foto.jpg")
    foto = foto.resize((100, 130), Image.BILINEAR)
    foto_tk = ImageTk.PhotoImage(foto)
    canvas.create_image(15, 90, anchor=tk.NW, image=foto_tk)
    canvas.imagen_foto = foto_tk  # Almacenar la imagen en el atributo del canvas

# Crear la ventana principal
ventana_principal = tk.Tk()
ventana_principal.geometry("600x500")
ventana_principal.configure(background="black")
ventana_principal.title("Proyecto programado #2")
canvasC1 = tk.Canvas(ventana_principal, width=500, height=350, borderwidth=0, highlightthickness=0, bg=negro)
canvasC1.place(x=300, y=245, anchor=tk.CENTER)
imagen_titulo = tk.PhotoImage(file="titulo.png")

# Crear una etiqueta con fondo negro y mostrar la imagen
etiqueta = tk.Label(ventana_principal, image=imagen_titulo, bg="black")
etiqueta.place(x=70, y=25)


# Crear la nueva ventana para el juego
ventana_nueva = tk.Toplevel(ventana_principal)
ventana_nueva.geometry("940x720")
ventana_nueva.title("PAC-MAN")
ventana_nueva.configure(background="#3E5F8A")
ventana_nueva.withdraw()  # Oculta la ventana nueva al principio
canvasC2 = tk.Canvas(ventana_nueva, width=720, height=648, borderwidth=0, highlightthickness=0, bg=negro)
canvasC2.place(x=470, y=355, anchor=tk.CENTER)

# Funcion para crear paredes

def paredes():
    canvasC2.create_rectangle(0,0, 719, 647, fill="blue",tags="rec")
    canvasC2.create_rectangle(36, 36, 90, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 36, 180, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(126, 36, 180, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 144, 144, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(90, 216, 108, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(0, 288, 252, 342, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 360, 126, 414, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 360, 90, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(54, 504, 108, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(54, 576, 342, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 432, 144, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 432, 684, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(198, 180, 254, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(144, 504, 198, 598, fill="black",tags="rec")
    canvasC2.create_rectangle(378, 576, 666, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(180, 108, 594, 162, fill="black",tags="rec")
    canvasC2.create_rectangle(198, 180, 522, 234, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 36, 468, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(540, 36, 684, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 90, 288, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(324, 90, 378, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(414, 90, 468, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(540, 36, 594, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(630, 36, 684, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(612, 216, 684, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(594, 144, 648, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 162, 288, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(432, 162, 486, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(342, 230, 396, 243, fill="black",tags="rec")
    canvasC2.create_rectangle(270, 252, 450, 324, fill="black",tags="rec")
    canvasC2.create_rectangle(144, 504, 576, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(500, 288, 720, 342, fill="black",tags="rec")
    canvasC2.create_rectangle(594, 360, 684, 414, fill="black",tags="rec")
    canvasC2.create_rectangle(630, 360, 684, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(612, 504, 666, 575, fill="black",tags="rec")
    canvasC2.create_rectangle(468,180,522,530, fill="black",tags="rec")
    canvasC2.create_rectangle(522, 558, 576, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(414, 558, 468, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(252, 558, 306, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(252, 342, 468, 396, fill="black",tags="rec")
    canvasC2.create_rectangle(324, 396, 378, 450, fill="black",tags="rec")
    
    
paredes()

# Crear la nueva ventana para ayuda
ventana_help = tk.Toplevel(ventana_principal)
ventana_help.geometry("450x350")
ventana_help.title("Ayuda")
ventana_help.configure(background="#3E5F8A")
ventana_help.withdraw()
canvasC4 = tk.Canvas(ventana_help, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC4.place(x=225, y=175, anchor=tk.CENTER)
canvasC4.create_text(197, 20, text=" ", font=(timesnewroman, 12), fill=negro)

# Crear la nueva ventana para salon de la fama
ventana_salon = tk.Toplevel(ventana_principal)
ventana_salon.geometry("450x350")
ventana_salon.title("Salon de la fama")
ventana_salon.configure(background="#3E5F8A")
ventana_salon.withdraw()
canvasC5 = tk.Canvas(ventana_salon, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC5.place(x=225, y=175, anchor=tk.CENTER)
canvasC5.create_text(197, 20, text=" ", font=(timesnewroman, 12), fill=negro)

# Crear la nueva ventana para acerca de
ventana_acerca = tk.Toplevel(ventana_principal)
ventana_acerca.geometry("450x350")
ventana_acerca.title("Acerca de")
ventana_acerca.configure(background="#3E5F8A")
ventana_acerca.withdraw()
canvasC6 = tk.Canvas(ventana_acerca, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC6.place(x=225, y=175, anchor=tk.CENTER)
#subir_foto(canvasC6)
#subir_bandera(canvasC6)
#canvasC6.create_text(250,100, text=" Estudiante: Steven Solano Zuñiga", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(200, 135, text=" Carné: 2019077611", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(259, 170, text=" Curso: Introducción a la programación", font=(timesnewroman, 12), fill=negro)
#canvasC6.create_text(239, 205, text=" Profesor: Jeff Schmidt Peralta", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(190, 290, text="     Producido en: CR                     Año:2023                     v1.0.0", font=(timesnewroman, 11), fill=negro)
#canvasC6.create_text(200, 250, text="-----------------------------------------------------------------", font=(timesnewroman, 13), fill=negro)



# Funcion para iniciar juego con nombre de usuario
def comprobar_usuario(entry):
    nombre = str(entry.get()).strip()
    if not nombre:
        canvasC1.delete("all")
        canvasC1.create_text(247, 145, text="Error: Debe ingresar su nombre para continuar", font=("Impact", 13), fill=rojo)
    else:
        canvasC1.delete("all")
        mostrar_ventana(ventana_nueva)
        PlayCancionG()
        ghost1.iniciar_mov_fantasma()
        ghost3.iniciar_mov_fantasma()
        ghost2.iniciar_mov_fantasma()
        ghost4.iniciar_mov_fantasma()
        #mover_pacman_izquierda_aux()
        #pacman.Mover_Izquierda()
        #pacman.mover_pacman_derecha()
        #pacman.mover_pacman_abajo()
        #pacman.Mover_Abajo()
        
        #Funciones especificas del juego

# Funcion para cerrar el juego
def cerrar_aplicacion():
    ventana_principal.quit()
    ventana_principal.destroy()

canvasC1.delete("all")
canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco)

# Calcular el centro de la pantalla
ancho_pantalla = ventana_principal.winfo_screenwidth()
alto_pantalla = ventana_principal.winfo_screenheight()
x_centro = (ancho_pantalla - 700) // 2  # El ancho de la ventana principal es 700
y_centro = (alto_pantalla - 600) // 2   # El alto de la ventana principal es 600

# Establecer la posición de la ventana principal en el centro
ventana_principal.geometry(f"600x500+{x_centro}+{y_centro}")

# Agregar nombre
usuario = tk.Entry(ventana_principal, font=(impact, 12), justify="center")
usuario.pack()
usuario.place(x=303, y=190, anchor=tk.CENTER)

# Botón para abrir una nueva ventana
boton_abrir = tk.Button(ventana_principal, text="Comenzar juego",font=(timesnewroman, 13),fg=blanco, command=lambda: comprobar_usuario(usuario),bg=verde)
boton_abrir.pack()
boton_abrir.place(x=297, y=460, anchor=tk.CENTER)

# Botón para ayuda y regresar 
ayuda = PhotoImage(file="ayuda.png").subsample(3,3)
boton_ayuda = tk.Button(ventana_principal,image=ayuda,font=(timesnewroman, 10),fg=blanco, command=lambda: mostrar_ventana(ventana_help),bg=celeste)
boton_ayuda.pack()
boton_ayuda.place(x=533, y=404, anchor=tk.CENTER)

# Botón para salon de la fama
fama = PhotoImage(file="fama.png").subsample(6,6)
boton_fama = tk.Button(ventana_principal,compound="left",image=fama,text="Salon de la fama",font=(timesnewroman, 12),fg=blanco, command=lambda: mostrar_ventana(ventana_salon),bg=celesteoscuro)
boton_fama.pack()
boton_fama.place(x=198, y=320, anchor=tk.CENTER)

# Botón para Acerca de
acerca = PhotoImage(file="acerca.png").subsample(12,12)
boton_acerca = tk.Button(ventana_principal,compound="left",image=acerca,text="  Acerca de ",font=(timesnewroman, 12),fg=blanco, command=lambda: mostrar_ventana(ventana_acerca),bg=celesteoscuro)
boton_acerca.pack()
boton_acerca.place(x=420, y=320, anchor=tk.CENTER)

# Botón exit
boton_exit = tk.Button(ventana_principal,text="Salir ",font=(timesnewroman, 12),fg=blanco, command=lambda: cerrar_aplicacion(),bg=rojo)
boton_exit.pack()
boton_exit.place(x=76, y=404, anchor=tk.CENTER)

# Calcular el centro de la pantalla para las nuevas ventanas
x_centro_nueva = (ancho_pantalla - 940) // 2
y_centro_nueva = (alto_pantalla - 750) // 2
x_centro_ayuda = (ancho_pantalla - 450) // 2
y_centro_ayuda = (alto_pantalla - 450) // 2
x_centro_fama = (ancho_pantalla - 450) // 2
y_centro_fama = (alto_pantalla -450) // 2
x_centro_acerca = (ancho_pantalla - 450) // 2
y_centro_acerca = (alto_pantalla - 450) // 2


# Establecer la posición de las ventanas al centro
ventana_nueva.geometry(f"940x720+{x_centro_nueva}+{y_centro_nueva}")
ventana_help.geometry(f"450x350+{x_centro_ayuda}+{y_centro_ayuda}")
ventana_salon.geometry(f"450x350+{x_centro_fama}+{y_centro_fama}")
ventana_acerca.geometry(f"450x350+{x_centro_acerca}+{y_centro_acerca}")

# Botón para regresar a la ventana principal desde la nueva ventana
atras = PhotoImage(file="atras.png").subsample(15, 15)
boton_regresar = tk.Button(ventana_nueva, image=atras, text="",font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=gris)
boton_regresar.pack()
boton_regresar.place(x=36, y=600, anchor=tk.CENTER)


# Botones para regresar a la pantalla inicial
regresar1 = PhotoImage(file="atras.png").subsample(15, 15)
boton_regresar2 = tk.Button(canvasC4, image=regresar1, text=" Inicio  ",font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=azulclaro)
boton_regresar2.pack()
boton_regresar2.place(x=48, y=280, anchor=tk.CENTER)
boton_regresar3 = tk.Button(canvasC5, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=celeste)
boton_regresar3.pack()
boton_regresar3.place(x=19, y=282, anchor=tk.CENTER)
boton_regresar4 = tk.Button(canvasC6, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=celeste)
boton_regresar4.pack()
boton_regresar4.place(x=19, y=19, anchor=tk.CENTER)


matriz=[]
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz.append([0,0,9,9,9,9,9,9,9,9,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0,0,9,9,9,9,9,9,9,9,0,0])																	
matriz.append([0,0,9,2,1,1,1,1,1,9,0,0,0,9,1,1,1,1,1,2,1,1,1,1,1,9,0,0,0,0,9,1,1,1,1,1,2,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,0,0,9,1,9,9,9,9,1,9,9,9,9,1,9,0,0,0,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,9,1,9,0,0,0,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,1,9,9,9,9,1,9,9,9,9,9,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,3,1,1,1,9,0,0,0,9,1,9,0,0,0,0,0,0,0,0,9,1,9,0,0,0,9,1,1,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,9,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,9,0,9,1,9,0,9,1,9,0,0,0,0,0,9,9,9,0,0,0,0,9,1,9,0,9,1,9,0,9,1,3,9,0,0])																	
matriz.append([0,0,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,0,0])																	
matriz.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz.append([1,1,3,1,1,1,1,1,1,1,1,1,2,9,0,9,9,9,9,9,9,9,9,9,9,0,9,2,1,1,1,1,1,1,1,1,1,3,1,1])																	
matriz.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz.append([0,0,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,9,0,9,1,9,9,9,9,9,9,0,0])																	
matriz.append([0,0,9,1,1,1,1,1,1,9,0,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,9,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,0,0,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,0,0,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,9,0,0,9,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,9,0,0])																	
matriz.append([0,0,9,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,0,0,9,1,9,9,0,0])																	
matriz.append([0,0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,0])																	
matriz.append([0,0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,0,0,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0,0])																	
matriz.append([0,0,0,9,2,1,1,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,1,1,3,1,1,1,1,1,1,1,1,2,9,0,0,0])																	
matriz.append([0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0])																	
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])


# Funcion para dibujar matriz (posible inspector)
def dibujar_matriz(matriz):
    ancho = canvasC2.winfo_reqwidth()
    alto = canvasC2.winfo_reqheight()
    
    # Calcula el ancho y alto de una celda en el canvas
    ancho_celda = ancho // len(matriz[0])
    alto_celda = alto // len(matriz)
    
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            x = (j + 0.5) * ancho_celda  # Centrar el elemento horizontalmente
            y = (i + 0.5) * alto_celda  # Centrar el elemento verticalmente
            valor = str(matriz[i][j])
            if valor=="1":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=verde,tags="matriz_texto")
            elif valor=="2":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=rojo,tags="matriz_texto")
            elif valor=="3":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=amarillo,tags="matriz_texto")
            elif valor=="9":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=gris,tags="matriz_texto")
            else:
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=azul,tags="matriz_texto")
            canvasC2.tag_raise("matriz_texto")
            



# Dibujar la matriz en el canvasC2
#dibujar_matriz(matriz)

# Imagenes de pacman
pacman_iz = tk.PhotoImage(file="pacman_iz.png").subsample(5, 5)
pacman_de = tk.PhotoImage(file="pacman_de.png").subsample(5, 5)
pacman_ar = tk.PhotoImage(file="pacman_ar.png").subsample(5, 5)
pacman_ab = tk.PhotoImage(file="pacman_ab.png").subsample(5, 5)
pacman_iz2 = tk.PhotoImage(file="pacman_iz2.png").subsample(5, 5)
pacman_de2 = tk.PhotoImage(file="pacman_de2.png").subsample(5, 5)
pacman_ar2 = tk.PhotoImage(file="pacman_ar2.png").subsample(5, 5)
pacman_ab2 = tk.PhotoImage(file="pacman_ab2.png").subsample(5, 5)
pacman_muere1 = tk.PhotoImage(file="muere1.png").subsample(4, 4)
pacman_muere2 = tk.PhotoImage(file="muere2.png").subsample(4, 4)
pacman_muere3 = tk.PhotoImage(file="muere3.png").subsample(4, 4)
pacman_muere4 = tk.PhotoImage(file="muere4.png").subsample(4, 4)
pacman_muere5 = tk.PhotoImage(file="muere5.png").subsample(4, 4)

#pacman_img = canvasC2.create_image(19*18-5, 20*18-5, anchor=tk.NW, image=pacman_iz,tags="pacman")

# Imagenes de las bolitas

bolita1= tk.PhotoImage(file="bol1.png").subsample(8, 8)
bolita2= tk.PhotoImage(file="bol2.png").subsample(8, 8)
bolita3= tk.PhotoImage(file="bol3.png").subsample(8, 8)
bolita4= tk.PhotoImage(file="bol4.png").subsample(8, 8)
bolota = tk.PhotoImage(file="BOL.png").subsample(15, 15)
cerezas = tk.PhotoImage(file="cerezas.png").subsample(7, 7)
banano = tk.PhotoImage(file="banano.png").subsample(14, 14)
fresa = tk.PhotoImage(file="fresa.png").subsample(9, 9)

lista_bolas = [bolita1,bolita3,bolita4]
lista_frutas = [cerezas,banano,fresa]

cantidad_8 = 1
               
mov_ab = False
mov_ar = False
mov_iz = False
mov_de = False
                 
########################################################################################################################### 
#                                                  INICIA CLASE PACMAN                                                    #
########################################################################################################################### 
global puntos
puntos = 0
class PACMAN:
    def __init__(self,Estado):
        self.Estado = Estado
        self.PosicionX = 337 # (19*18)-5
        self.PosicionY = 355 # (20*18)-5
        self.Velocidad = 1 # velocidad normal
        if Estado=="vivo":
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY, image=pacman_iz,anchor=tk.NW,tags="pacman")
        else:
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY,anchor=tk.NW,tags="pacman")
        canvasC2.tag_lower("RedGhost","pacman")
###########################################################################################################################        
    def Mover_Izquierda(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_ab = False
        mov_de = False
        if not mov_iz and self.Estado=="vivo":
            mov_iz = True
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_iz = False
        mov_ab = False
        if not mov_de and self.Estado=="vivo":
            mov_de = True
            return self.mover_pacman_derecha_aux()
    def mover_pacman_abajo(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_iz = False
        mov_de = False
        if not mov_ab and self.Estado=="vivo":
            mov_ab = True
            return self.mover_pacman_abajo_aux()
    def mover_pacman_arriba(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ab = False
        mov_iz = False
        mov_de = False
        if not mov_ar and self.Estado=="vivo":
            mov_ar = True
            return self.mover_pacman_arriba_aux()
########################################################################################################################### 
    def mover_pacman_izquierda_aux(self):
        global puntos
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen,image=pacman_iz, tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX <= 0:
            canvasC2.coords(self.Imagen, 702, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        
        if j.is_integer():
            j = int(j)
        elif (j-int(j)<0.5):
            j=int(j)
        else:
            j=int(j)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (j-int(j/18)>0.5):
            self.PosicionX=(int(j))*18
            canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento == 1:
                puntos += 10
            if elemento == 2:
                puntos += 20
            if elemento == 3:
                puntos += 50
            actualizar_cantidad()
            a=int((self.PosicionX)/18)
            b=int((self.PosicionY)/18)
            c=int(ghost1.posx/18)
            d=int(ghost1.posy/18)
            if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                self.Estado="MUERTO"
                ghost1.estado="muerto"
                canvasC2.delete(ghost1.Ghost_img)
                return self.secuencia_muerte(1)
            if not (matriz[int(i)][int(j)-1]!=9):
                mov_iz = False
                return -1
            if not self.Estado=="MUERTO":
                return self.mover_pacman_izquierda_aux_2(cont)  
        else:
            mov_iz = False
    def mover_pacman_derecha_aux(self):
        global puntos
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX+18>=702:
            canvasC2.coords(self.Imagen, 0, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if j.is_integer():
            j = int(j)
        elif (j-int(j)<0.5):
            j=int(j)
        else:
            j=int(j)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (j-int(j/18)>0.5):
            self.PosicionX=(int(j))*18
            canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento == 1:
                puntos += 10
            if elemento == 2:
                puntos += 20
            if elemento == 3:
                puntos += 50
            actualizar_cantidad()
            a=int((self.PosicionX)/18)
            b=int((self.PosicionY)/18)
            c=int(ghost1.posx/18)
            d=int(ghost1.posy/18)
            if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                self.Estado="MUERTO"
                ghost1.estado="muerto"
                return self.secuencia_muerte(1)
            if not (matriz[int(i)][int(j)+1]!=9):
                mov_de = False
                return -1
            if not self.Estado=="MUERTO":
                return self.mover_pacman_derecha_aux_2(cont)  
        else:
            mov_de = False
    def mover_pacman_arriba_aux(self):
        global puntos
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.PosicionY=(int(i))*18
            canvasC2.coords(self.Imagen, self.PosicionX, self.PosicionY-5)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento == 1:
                puntos += 10
            if elemento == 2:
                puntos += 20
            if elemento == 3:
                puntos += 50
            actualizar_cantidad()
            a=int((self.PosicionX)/18)
            b=int((self.PosicionY)/18)
            c=int(ghost1.posx/18)
            d=int(ghost1.posy/18)
            if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                self.Estado="MUERTO"
                ghost1.estado="muerto"
                return self.secuencia_muerte(1)
            if not (matriz[int(i)-1][int(j)]!=9):
                mov_ar = False
                return -1
            if not self.Estado=="MUERTO":
                return self.mover_pacman_arriba_aux_2(cont) 
        else:
            mov_ar = False
    def mover_pacman_abajo_aux(self):
        global ghost1
        global puntos
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.PosicionY=(int(i))*18
            canvasC2.coords(self.Imagen, self.PosicionX, self.PosicionY-5)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento == 1:
                puntos += 10
            if elemento == 2:
                puntos += 20
            if elemento == 3:
                puntos += 50
            actualizar_cantidad()
            a=int((self.PosicionX)/18)
            b=int((self.PosicionY)/18)
            c=int(ghost1.posx/18)
            d=int(ghost1.posy/18)
            if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                self.Estado="MUERTO"
                ghost1.estado="muerto"
                return self.secuencia_muerte(1)
            if not (matriz[int(i)+1][int(j)]!=9):
                mov_ab = False
                return -1
            if not self.Estado=="MUERTO":
                return self.mover_pacman_abajo_aux_2(cont) 
        else:
            mov_ab = False
            
    def secuencia_muerte(self,cont):
        canvasC2.delete(ghost1.Ghost_img)
        canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY-5)
        global pacman_muere1,pacman_muere2,pacman_muere3,pacman_muere4,pacman_muere5
        if cont == 1:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere1, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
        elif cont == 2:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere2, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
        elif cont == 3:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere3, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
        elif cont == 4:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere4, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
        elif cont == 5:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere5, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
        
########################################################################################################################### 
    def mover_pacman_izquierda_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz2,tags="pacman")
            if not mov_de and not mov_ar and not mov_ab and not self.Estado=="MUERTO":
                canvasC2.move(self.Imagen , -1, 0)
                ventana_nueva.after(6, self.mover_pacman_izquierda_aux_2, cont + 1)
        else:
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_de2,tags="pacman")
            if not mov_iz and not mov_ar and not mov_ab and not self.Estado=="MUERTO":
                canvasC2.move(self.Imagen, 1, 0)
                ventana_nueva.after(6, self.mover_pacman_derecha_aux_2, cont + 1)
        else:
            return self.mover_pacman_derecha_aux()
    def mover_pacman_arriba_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ab and not self.Estado=="MUERTO":
                canvasC2.move(self.Imagen, 0, -1)
                ventana_nueva.after(6, self.mover_pacman_arriba_aux_2, cont + 1)
        else:
            return self.mover_pacman_arriba_aux()
    def mover_pacman_abajo_aux_2(self, cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ar and not self.Estado=="MUERTO":
                canvasC2.move(self.Imagen, 0, +1)
                ventana_nueva.after(6, self.mover_pacman_abajo_aux_2, cont + 1)
        else:
            return self.mover_pacman_abajo_aux()
###########################################################################################################################
###########################################################################################################################



def asignar_bolas():
    global cantidad_8
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            valor = str(matriz[i][j])
            if valor=="2":
                canvasC2.create_image(j*18, i*18, anchor=tk.NW, image=bolota,tags="bolas")
            elif valor=="3":
                imagen_seleccionada = random.choice(lista_frutas)
                if imagen_seleccionada==fresa:
                    canvasC2.create_image(j*18+2, i*18-4, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")
                else:
                    canvasC2.create_image(j*18-4, i*18-4, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")

            elif valor=="1":
                imagen_seleccionada = random.choice(lista_bolas)
                canvasC2.create_image(j*18+5, i*18+5, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")



        
                
            
                           
asignar_bolas()
canvasC2.tag_lower("rec","bolas") 
pacman = PACMAN("vivo")


#actualizar_cantidad: Función que muestra la cantidad de puntos en la pantalla de juego
#E: global puntos
#S: la cantidad de puntos
#R: puntos debe ser un entero
def actualizar_cantidad():
    global puntos
    cantidad.config(text='Puntos : {}'.format(puntos))

# Crear una etiqueta para mostrar la cantidad de puntos
cantidad = Label(ventana_nueva, text='Puntos : {}'.format(puntos), bg='black', fg='red', font=('Arial', 12, 'bold'))
cantidad.place(x=0, y=0)


def PlayCancionG():  # funcion para reproducir la cancion
    return py.mixer.Sound.play(sonido_fondo, -1)  # Con -1 se indica que se reproduzca la cancion indefinidamente
sonido_fondo = py.mixer.Sound("sonidos\cancionfondo.mp3")

# se carga el sonido indicando la ruta
def StopCancionG():  # funcion para pausar la cancion
    py.mixer.Sound.stop(sonido_fondo)

playG = Button(ventana_nueva, text="PLAY", bg="green", fg="black", command=lambda: PlayCancionG())  # boton de reproducir la cancion
playG.place(x=30, y=50)
stopG = Button(ventana_nueva, text="STOP", bg="red", fg="black", command=lambda: StopCancionG())  # boton de detener la cancion
stopG.place(x=30, y=100)


#imagenes de fantasmas
RedGhost_iz = tk.PhotoImage(file="fantasma_r_iz.png").subsample(5, 5)
RedGhost_de = tk.PhotoImage(file="fantasma_r_de.png").subsample(5, 5)
RedGhost_ar = tk.PhotoImage(file="fantasma_r_ar.png").subsample(5, 5)
RedGhost_ab = tk.PhotoImage(file="fantasma_r_ab.png").subsample(5, 5)

BlueGhost_iz = tk.PhotoImage(file="fantasma_c_iz.png").subsample(5, 5)
BlueGhost_de = tk.PhotoImage(file="fantasma_c_de.png").subsample(5, 5)
BlueGhost_ar = tk.PhotoImage(file="fantasma_c_ar.png").subsample(5, 5)
BlueGhost_ab = tk.PhotoImage(file="fantasma_c_ab.png").subsample(5, 5)

PinkGhost_iz = tk.PhotoImage(file="fantasma_p_iz.png").subsample(5, 5)
PinkGhost_de = tk.PhotoImage(file="fantasma_p_de.png").subsample(5, 5)
PinkGhost_ar = tk.PhotoImage(file="fantasma_p_ar.png").subsample(5, 5)
PinkGhost_ab = tk.PhotoImage(file="fantasma_p_ab.png").subsample(5, 5)

OrangeGhost_iz = tk.PhotoImage(file="fantasma_a_iz.png").subsample(5, 5)
OrangeGhost_de = tk.PhotoImage(file="fantasma_a_de.png").subsample(5, 5)
OrangeGhost_ar = tk.PhotoImage(file="fantasma_a_ar.png").subsample(5, 5)
OrangeGhost_ab = tk.PhotoImage(file="fantasma_a_ab.png").subsample(5, 5)


######################################################################
######################################################################

#crear fantasmas
class Ghost:
    def __init__(self, estado, posx, posy, color, velocidad):
        self.estado = estado
        self.posx = posx
        self.posy = posy
        self.color = color
        self.velocidad = velocidad     
        
###########################################################################################################################
    def mover_Ghost_izquierda(self):
        global mov_ghost_ab,mov_ghost_ar,mov_ghost_iz,mov_ghost_de
        mov_ghost_ar = False
        mov_ghost_ab = False
        mov_ghost_de = False
        if not mov_ghost_iz and not self.estado=="muerto":
            mov_ghost_iz = True
            return self.mover_Ghost_izquierda_aux()
    def mover_Ghost_derecha(self):
        global mov_ghost_ab,mov_ghost_ar,mov_ghost_iz,mov_ghost_de
        mov_ghost_ar = False
        mov_ghost_ab = False
        mov_ghost_iz = False
        if not mov_ghost_de and not self.estado=="muerto":
            mov_ghost_de = True
            return self.mover_Ghost_derecha_aux()
    def mover_Ghost_abajo(self):
        global mov_ghost_ab,mov_ghost_ar,mov_ghost_iz,mov_ghost_de
        mov_ghost_armov_ghost_ar = False
        mov_ghost_iz = False
        mov_ghost_de = False
        if not mov_ghost_ab and not self.estado=="muerto":
            mov_ghost_ab = True
            return self.mover_Ghost_abajo_aux()
    def mover_Ghost_arriba(self):
        global mov_ghost_ab,mov_ghost_ar,mov_ghost_iz,mov_ghost_de
        mov_ghost_ab = False
        mov_ghost_iz = False
        mov_ghost_de = False
        if not mov_ghost_ar and not self.estado=="muerto":
            mov_ghost_ar = True
            return self.mover_Ghost_arriba_aux()
###########################################################################################################################
    def opciones(self,i,j,lista):
        global matriz
        global mov_ghost_ar, mov_ghost_ab,mov_ghost_iz,mov_ghost_de
        arriba = abajo = izquierda = derecha = False
        if matriz[i-1][j]!=9:
            arriba=True
            mov_ghost_ar=False
            lista.append("arriba")
        if matriz[i+1][j]!=9:
            abajo=True
            mov_ghost_ab=False
            lista.append("abajo")
        if matriz[i][j+1]!=9:
            derecha=True
            mov_ghost_de=False
            lista.append("derecha")
        if matriz[i][j-1]!=9:
            izquierda = True
            mov_ghost_iz=False
            lista.append("izquierda")
        direccion = random.choice(lista)
        return direccion
###########################################################################################################################        
    def mover_Ghost_izquierda_aux(self):
        global matriz
        if self.color == "Rojo":
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_iz, tags="RedGhost")
        elif self.color == "Celeste":
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_iz, tags="RedGhost")     
        elif self.color == "Rosado":
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_iz, tags="RedGhost")
        elif self.color == "Naranja":
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_iz, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        if self.posx <= 0:
            canvasC2.coords(self.Ghost_img, 702, self.posy)
            self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy + 6) / 18)
        j = ((self.posx + 6) / 18)
        if j.is_integer():
            j = int(j)
        elif (j - int(j) < 0.5):
            j = int(j)
        else:
            j = int(j) + 1
        elemento = matriz[int(i)][int(j)]
        cont = 0
        if (j - int(j / 18) > 0.5):
            self.posx = (int(j)) * 18
            canvasC2.coords(self.Ghost_img, self.posx - 6, self.posy)
        if elemento == 1 or elemento == 8 or elemento == 3 or elemento == 2:
            opciones=[]
            if not self.posx==702:
                if (matriz[int(i-1)][int(j)]!=9):
                    opciones.append("arriba")
                if (matriz[int(i+1)][int(j)]!=9):
                    opciones.append("abajo")
                if (matriz[int(i)][int(j) - 1] == 9):
                    mov_ghost_iz = False
                    lista_opciones = []
                    direccion = self.opciones(int(i), int(j), lista_opciones)
                    funcion = getattr(self, f'mover_Ghost_{direccion}')
                    try:
                        ventana_nueva.after(0, funcion)
                    except Exception as e:
                        print("hay un error")
                else:
                    opciones.append("izquierda")
                    opcion=random.choice(opciones)
                    funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                    ventana_nueva.after(6, funcion,cont)
            else:
                return mover_ghost_derecha_aux()
        else:
            mov_ghost_iz = False
    def mover_Ghost_derecha_aux(self):
        global matriz
        if self.color == "Rojo":
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_de, tags="RedGhost")
        elif self.color == "Celeste":
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_de, tags="RedGhost")     
        elif self.color == "Rosado":
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_de, tags="RedGhost")
        elif self.color == "Naranja":
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_de, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        if self.posy +18>=702:
            canvasC2.coords(self.Ghost_img, 0, self.posy)
            self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy + 6) / 18)
        j = ((self.posx + 6) / 18)
        if j.is_integer():
            j = int(j)
        elif (j - int(j) < 0.5):
            j = int(j)
        else:
            j = int(j) + 1
        elemento = matriz[int(i)][int(j)]
        cont = 0
        if (j - int(j / 18) > 0.5):
            self.posx = (int(j)) * 18
            canvasC2.coords(self.Ghost_img, self.posx - 6, self.posy)
        if elemento == 1 or elemento == 8 or elemento == 3 or elemento == 2:
            opciones=[]
            if not self.posx==0:
                if (matriz[int(i-1)][int(j)]!=9):
                    opciones.append("arriba")
                if (matriz[int(i+1)][int(j)]!=9):
                    opciones.append("abajo")
                if (matriz[int(i)][int(j) + 1] == 9):
                    mov_ghost_de = False
                    lista_opciones = []
                    direccion = self.opciones(int(i), int(j), lista_opciones)
                    funcion = getattr(self, f'mover_Ghost_{direccion}')
                    try:
                        ventana_nueva.after(0, funcion)
                    except Exception as e:
                        print("hay un error")
                else:
                    opciones.append("derecha")
                    opcion=random.choice(opciones)
                    funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                    ventana_nueva.after(6, funcion,cont)
            else:
                return mover_ghost_izquierda_aux()
        else:
            mov_ghost_de = False
    def mover_Ghost_abajo_aux(self):
        global matriz
        if self.color == "Rojo":
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_ab, tags="RedGhost")
        elif self.color == "Celeste":
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_ab, tags="RedGhost")     
        elif self.color == "Rosado":
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_ab, tags="RedGhost")
        elif self.color == "Naranja":
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_ab, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy+6) / 18)
        j = ((self.posx+6) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.posy=(int(i))*18
            canvasC2.coords(self.Ghost_img, self.posx, self.posy-6)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            opciones=[]
            if (matriz[int(i)][int(j-1)]!=9):
                opciones.append("izquierda")
            if (matriz[int(i)][int(j+1)]!=9):
                opciones.append("derecha")
            if (matriz[int(i)+1][int(j)] == 9):
                mov_ghost_ab = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("abajo")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            mov_ghost_ab = False
    def mover_Ghost_arriba_aux(self):
        global matriz
        if self.color == "Rojo":
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_ar, tags="RedGhost")
        elif self.color == "Celeste":
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_ar, tags="RedGhost")     
        elif self.color == "Rosado":
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_ar, tags="RedGhost")
        elif self.color == "Naranja":
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_ar, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy+6) / 18)
        j = ((self.posx+6) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.posy=(int(i))*18
            canvasC2.coords(self.Ghost_img, self.posx, self.posy-6)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            opciones=[]
            if (matriz[int(i)][int(j-1)]!=9 ):
                opciones.append("izquierda")
            if (matriz[int(i)][int(j+1)]!=9):
                opciones.append("derecha")
            if (matriz[int(i)-1][int(j)] == 9):
                mov_ghost_ar = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("arriba")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            mov_ghost_ar = False
    
    

            
###########################################################################################################################
    def mover_Ghost_izquierda_aux_2(self, cont):
        if cont < 18 and not self.estado=="muerto":
            canvasC2.move(self.Ghost_img, -1, 0)
            ventana_nueva.after(6, self.mover_Ghost_izquierda_aux_2, cont + 1)
        else:
            return self.mover_Ghost_izquierda_aux()
        
    def mover_Ghost_derecha_aux_2(self, cont):
        if cont < 18 and not self.estado=="muerto":
            canvasC2.move(self.Ghost_img, +1, 0)
            ventana_nueva.after(6, self.mover_Ghost_derecha_aux_2, cont + 1)
        else:
            return self.mover_Ghost_derecha_aux()

    def mover_Ghost_abajo_aux_2(self, cont):
        if cont < 18 and not self.estado=="muerto":
            canvasC2.move(self.Ghost_img, 0, +1)
            ventana_nueva.after(6, self.mover_Ghost_abajo_aux_2, cont + 1)
        else:
            return self.mover_Ghost_abajo_aux()

    def mover_Ghost_arriba_aux_2(self, cont):
        if cont < 18 and not self.estado=="muerto":
            canvasC2.move(self.Ghost_img, 0, -1)
            ventana_nueva.after(6, self.mover_Ghost_arriba_aux_2, cont + 1)
        else:
            return self.mover_Ghost_arriba_aux()
    
###########################################################################################################################

    #def mover_derecha(self):
    #def mover_arriba(self):
    #def mover_abajo(self):
        
    def crear_fantasma(self):
        if self.color == "Rojo":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=RedGhost_iz, tags="RedGhost")
        elif self.color == "Celeste":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=BlueGhost_iz, tags="BlueGhost")     
        elif self.color == "Rosado":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=PinkGhost_iz, tags="PinkGhost")
        elif self.color == "Naranja":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=OrangeGhost_iz, tags="OrangeGhost")


    def iniciar_mov_fantasma(self):
        x,y = canvasC2.coords(self.Ghost_img)
        
        if self.color == "Rojo":
            cont1 = 68
            cont2 = 78
        elif self.color == "Celeste":
            cont1 = 28
            cont2 = 78     
        elif self.color == "Rosado":
            cont1 = -13
            cont2 = 78
        elif self.color == "Naranja":
            cont1 = -50
            cont2 = 78

        if cont1>0:
            for i in range (cont1):
                canvasC2.move(self.Ghost_img, +1, 0)
                ventana_nueva.update()
                ventana_nueva.after(20)
        else:
            cont1=abs(cont1)
            for i in range (cont1):
                canvasC2.move(self.Ghost_img, -1, 0)
                ventana_nueva.update()
                ventana_nueva.after(20)
            
        for j in range (cont2):
            canvasC2.move(self.Ghost_img, 0, -1)
            ventana_nueva.update()
            ventana_nueva.after(20)
        canvasC2.coords(self.Ghost_img, 20*18-6, 11*18-6)
        self.movimiento_thread = Thread(target=self.mover_Ghost_izquierda)
        self.movimiento_thread.start()   

ghost1 = Ghost(estado="vivo", posx=19 * 18 - 55, posy=20 * 18 - 90, color="Rojo", velocidad=1)
ghost1.crear_fantasma()
ghost2 = Ghost(estado="vivo", posx=19 * 18 - 15, posy=20 * 18 - 90, color="Celeste", velocidad=1)
ghost2.crear_fantasma()
ghost3 = Ghost(estado="vivo", posx=19 * 18 + 25, posy=20 * 18 - 90, color="Rosado", velocidad=1)
ghost3.crear_fantasma()
ghost4 = Ghost(estado="vivo", posx=19 * 18 + 65, posy=20 * 18 - 90, color="Naranja", velocidad=1)
ghost4.crear_fantasma()


ventana_nueva.bind("<Left>", pacman.Mover_Izquierda)  # Asociar la tecla de flecha izquierda con mover_pacman_izquierda
ventana_nueva.bind("<Right>", pacman.mover_pacman_derecha)  # Asociar la tecla de flecha derecha con mover_pacman_derecha
ventana_nueva.bind("<Up>", pacman.mover_pacman_arriba)  # Asociar la tecla de flecha arriba con mover_pacman_arriba
ventana_nueva.bind("<Down>", pacman.mover_pacman_abajo)  # Asociar la tecla de flecha abajo con mover_pacman_abajo

mov_ghost_iz = False
mov_ghost_ab = False
mov_ghost_de = False
mov_ghost_ar = False


##########################################################################################

#crear fantasmas






ventana_actual = ventana_principal  # Inicialmente, la ventana actual es la principal

ventana_principal.mainloop()


