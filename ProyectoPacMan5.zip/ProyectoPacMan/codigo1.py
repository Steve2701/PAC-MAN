import tkinter as tk
from threading import Thread
from tkinter import PhotoImage,NW
from PIL import Image, ImageTk
import pygame as py
import time
import sys
import math
import random


#Colores
verde="#008F39"
navy = "#2B3467"
celeste = "#99B4D1"
celesteoscuro = "#296d98"
amarillo = "#FCFFE7"
rojo = "#EB455F"
gris = "#b5b5b5"
grisoscuro = "#666666"
azul = "#3E5F8A"
negro = "#000000"
blanco = "#FFFFFF"
azulclaro="#256d7b"
grisoscuro = "#666666"

#Fuentes
impact = "Impact"
arial="Arial"
timesnewroman="TimesNewRoman"

# Funcion para mostrar ventanas
def mostrar_ventana(ventana_a_mostrar):
    global ventana_actual
    usuario.delete(0, "end")
    canvasC1.delete("all")
    canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco)
    ventana_actual.withdraw()  # Oculta la ventana actual
    ventana_a_mostrar.deiconify()  # Muestra la nueva ventana
    ventana_actual = ventana_a_mostrar

def subir_foto(canvas):
    foto = Image.open("Foto.jpg")
    foto = foto.resize((100, 130), Image.BILINEAR)
    foto_tk = ImageTk.PhotoImage(foto)
    canvas.create_image(15, 90, anchor=tk.NW, image=foto_tk)
    canvas.imagen_foto = foto_tk  # Almacenar la imagen en el atributo del canvas

# Crear la ventana principal
ventana_principal = tk.Tk()
ventana_principal.geometry("600x500")
ventana_principal.configure(background="black")
ventana_principal.title("Proyecto programado #2")
canvasC1 = tk.Canvas(ventana_principal, width=500, height=350, borderwidth=0, highlightthickness=0, bg=negro)
canvasC1.place(x=300, y=245, anchor=tk.CENTER)
imagen_titulo = tk.PhotoImage(file="titulo.png")

# Crear una etiqueta con fondo negro y mostrar la imagen
etiqueta = tk.Label(ventana_principal, image=imagen_titulo, bg="black")
etiqueta.place(x=70, y=25)


# Crear la nueva ventana para el juego
ventana_nueva = tk.Toplevel(ventana_principal)
ventana_nueva.geometry("940x720")
ventana_nueva.title("PAC-MAN")
ventana_nueva.configure(background="#3E5F8A")
ventana_nueva.withdraw()  # Oculta la ventana nueva al principio
canvasC2 = tk.Canvas(ventana_nueva, width=720, height=648, borderwidth=0, highlightthickness=0, bg=negro)
canvasC2.place(x=470, y=355, anchor=tk.CENTER)

# Funcion para crear paredes

def paredes():
    canvasC2.create_rectangle(0,0, 719, 647, fill="blue",tags="rec")
    canvasC2.create_rectangle(36, 36, 90, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 36, 180, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(126, 36, 180, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 144, 144, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(90, 216, 108, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(0, 288, 252, 342, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 360, 126, 414, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 360, 90, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(54, 504, 108, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(54, 576, 342, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 432, 144, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(36, 432, 684, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(198, 180, 254, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(144, 504, 198, 598, fill="black",tags="rec")
    canvasC2.create_rectangle(378, 576, 666, 630, fill="black",tags="rec")
    canvasC2.create_rectangle(180, 108, 594, 162, fill="black",tags="rec")
    canvasC2.create_rectangle(198, 180, 522, 234, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 36, 468, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(540, 36, 684, 90, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 90, 288, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(324, 90, 378, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(414, 90, 468, 126, fill="black",tags="rec")
    canvasC2.create_rectangle(540, 36, 594, 486, fill="black",tags="rec")
    canvasC2.create_rectangle(630, 36, 684, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(612, 216, 684, 270, fill="black",tags="rec")
    canvasC2.create_rectangle(594, 144, 648, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(234, 162, 288, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(432, 162, 486, 198, fill="black",tags="rec")
    canvasC2.create_rectangle(342, 230, 396, 243, fill="black",tags="rec")
    canvasC2.create_rectangle(270, 252, 450, 324, fill="black",tags="rec")
    canvasC2.create_rectangle(144, 504, 576, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(500, 288, 720, 342, fill="black",tags="rec")
    canvasC2.create_rectangle(594, 360, 684, 414, fill="black",tags="rec")
    canvasC2.create_rectangle(630, 360, 684, 558, fill="black",tags="rec")
    canvasC2.create_rectangle(612, 504, 666, 575, fill="black",tags="rec")
    canvasC2.create_rectangle(468,180,522,530, fill="black",tags="rec")
    canvasC2.create_rectangle(522, 558, 576, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(414, 558, 468, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(252, 558, 306, 594, fill="black",tags="rec")
    canvasC2.create_rectangle(252, 342, 468, 396, fill="black",tags="rec")
    canvasC2.create_rectangle(324, 396, 378, 450, fill="black",tags="rec")
    
    
paredes()

# Crear la nueva ventana para ayuda
ventana_help = tk.Toplevel(ventana_principal)
ventana_help.geometry("450x350")
ventana_help.title("Ayuda")
ventana_help.configure(background="#3E5F8A")
ventana_help.withdraw()
canvasC4 = tk.Canvas(ventana_help, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC4.place(x=225, y=175, anchor=tk.CENTER)
canvasC4.create_text(197, 20, text=" ", font=(timesnewroman, 12), fill=negro)

# Crear la nueva ventana para salon de la fama
ventana_salon = tk.Toplevel(ventana_principal)
ventana_salon.geometry("450x350")
ventana_salon.title("Salon de la fama")
ventana_salon.configure(background="#3E5F8A")
ventana_salon.withdraw()
canvasC5 = tk.Canvas(ventana_salon, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC5.place(x=225, y=175, anchor=tk.CENTER)
canvasC5.create_text(197, 20, text=" ", font=(timesnewroman, 12), fill=negro)

# Crear la nueva ventana para acerca de
ventana_acerca = tk.Toplevel(ventana_principal)
ventana_acerca.geometry("450x350")
ventana_acerca.title("Acerca de")
ventana_acerca.configure(background="#3E5F8A")
ventana_acerca.withdraw()
canvasC6 = tk.Canvas(ventana_acerca, width=400, height=300, borderwidth=0, highlightthickness=0, bg=celeste)
canvasC6.place(x=225, y=175, anchor=tk.CENTER)
#subir_foto(canvasC6)
#subir_bandera(canvasC6)
#canvasC6.create_text(250,100, text=" Estudiante: Steven Solano Zuñiga", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(200, 135, text=" Carné: 2019077611", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(259, 170, text=" Curso: Introducción a la programación", font=(timesnewroman, 12), fill=negro)
#canvasC6.create_text(239, 205, text=" Profesor: Jeff Schmidt Peralta", font=(timesnewroman, 13), fill=negro)
#canvasC6.create_text(190, 290, text="     Producido en: CR                     Año:2023                     v1.0.0", font=(timesnewroman, 11), fill=negro)
#canvasC6.create_text(200, 250, text="-----------------------------------------------------------------", font=(timesnewroman, 13), fill=negro)



# Funcion para iniciar juego con nombre de usuario
def comprobar_usuario(entry):
    nombre = str(entry.get()).strip()
    if not nombre:
        canvasC1.delete("all")
        canvasC1.create_text(247, 145, text="Error: Debe ingresar su nombre para continuar", font=("Impact", 13), fill=rojo)
    else:
        canvasC1.delete("all")
        mostrar_ventana(ventana_nueva)
        #mover_pacman_izquierda_aux()
        #pacman.Mover_Izquierda()
        #pacman.mover_pacman_derecha()
        #pacman.mover_pacman_abajo()
        #pacman.Mover_Abajo()
        
        #Funciones especificas del juego

# Funcion para cerrar el juego
def cerrar_aplicacion():
    ventana_principal.quit()
    ventana_principal.destroy()

canvasC1.delete("all")
canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco)

# Calcular el centro de la pantalla
ancho_pantalla = ventana_principal.winfo_screenwidth()
alto_pantalla = ventana_principal.winfo_screenheight()
x_centro = (ancho_pantalla - 700) // 2  # El ancho de la ventana principal es 700
y_centro = (alto_pantalla - 600) // 2   # El alto de la ventana principal es 600

# Establecer la posición de la ventana principal en el centro
ventana_principal.geometry(f"600x500+{x_centro}+{y_centro}")

# Agregar nombre
usuario = tk.Entry(ventana_principal, font=(impact, 12), justify="center")
usuario.pack()
usuario.place(x=303, y=190, anchor=tk.CENTER)

# Botón para abrir una nueva ventana
boton_abrir = tk.Button(ventana_principal, text="Comenzar juego",font=(timesnewroman, 13),fg=blanco, command=lambda: comprobar_usuario(usuario),bg=verde)
boton_abrir.pack()
boton_abrir.place(x=297, y=460, anchor=tk.CENTER)

# Botón para ayuda y regresar 
ayuda = PhotoImage(file="ayuda.png").subsample(3,3)
boton_ayuda = tk.Button(ventana_principal,image=ayuda,font=(timesnewroman, 10),fg=blanco, command=lambda: mostrar_ventana(ventana_help),bg=celeste)
boton_ayuda.pack()
boton_ayuda.place(x=533, y=404, anchor=tk.CENTER)

# Botón para salon de la fama
fama = PhotoImage(file="fama.png").subsample(6,6)
boton_fama = tk.Button(ventana_principal,compound="left",image=fama,text="Salon de la fama",font=(timesnewroman, 12),fg=blanco, command=lambda: mostrar_ventana(ventana_salon),bg=celesteoscuro)
boton_fama.pack()
boton_fama.place(x=198, y=320, anchor=tk.CENTER)

# Botón para Acerca de
acerca = PhotoImage(file="acerca.png").subsample(12,12)
boton_acerca = tk.Button(ventana_principal,compound="left",image=acerca,text="  Acerca de ",font=(timesnewroman, 12),fg=blanco, command=lambda: mostrar_ventana(ventana_acerca),bg=celesteoscuro)
boton_acerca.pack()
boton_acerca.place(x=420, y=320, anchor=tk.CENTER)

# Botón exit
boton_exit = tk.Button(ventana_principal,text="Salir ",font=(timesnewroman, 12),fg=blanco, command=lambda: cerrar_aplicacion(),bg=rojo)
boton_exit.pack()
boton_exit.place(x=76, y=404, anchor=tk.CENTER)

# Calcular el centro de la pantalla para las nuevas ventanas
x_centro_nueva = (ancho_pantalla - 940) // 2
y_centro_nueva = (alto_pantalla - 750) // 2
x_centro_ayuda = (ancho_pantalla - 450) // 2
y_centro_ayuda = (alto_pantalla - 450) // 2
x_centro_fama = (ancho_pantalla - 450) // 2
y_centro_fama = (alto_pantalla -450) // 2
x_centro_acerca = (ancho_pantalla - 450) // 2
y_centro_acerca = (alto_pantalla - 450) // 2


# Establecer la posición de las ventanas al centro
ventana_nueva.geometry(f"940x720+{x_centro_nueva}+{y_centro_nueva}")
ventana_help.geometry(f"450x350+{x_centro_ayuda}+{y_centro_ayuda}")
ventana_salon.geometry(f"450x350+{x_centro_fama}+{y_centro_fama}")
ventana_acerca.geometry(f"450x350+{x_centro_acerca}+{y_centro_acerca}")

# Botón para regresar a la ventana principal desde la nueva ventana
atras = PhotoImage(file="atras.png").subsample(15, 15)
boton_regresar = tk.Button(ventana_nueva, image=atras, text="",font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=gris)
boton_regresar.pack()
boton_regresar.place(x=36, y=600, anchor=tk.CENTER)


# Botones para regresar a la pantalla inicial
regresar1 = PhotoImage(file="atras.png").subsample(15, 15)
boton_regresar2 = tk.Button(canvasC4, image=regresar1, text=" Inicio  ",font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=azulclaro)
boton_regresar2.pack()
boton_regresar2.place(x=48, y=280, anchor=tk.CENTER)
boton_regresar3 = tk.Button(canvasC5, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=celeste)
boton_regresar3.pack()
boton_regresar3.place(x=19, y=282, anchor=tk.CENTER)
boton_regresar4 = tk.Button(canvasC6, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=celeste)
boton_regresar4.pack()
boton_regresar4.place(x=19, y=19, anchor=tk.CENTER)


matriz=[]
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz.append([0,0,9,9,9,9,9,9,9,9,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0,0,9,9,9,9,9,9,9,9,0,0])																	
matriz.append([0,0,9,2,1,1,1,1,1,9,0,0,0,9,1,1,1,1,1,2,1,1,1,1,1,9,0,0,0,0,9,1,1,1,1,1,2,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,0,0,9,1,9,9,9,9,1,9,9,9,9,1,9,0,0,0,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,9,1,9,0,0,0,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,1,9,9,9,9,1,9,9,9,9,9,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,3,1,1,1,9,0,0,0,9,1,9,0,0,0,0,0,0,0,0,9,1,9,0,0,0,9,1,1,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,9,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,9,0,9,1,9,0,9,1,9,0,0,0,0,0,9,9,9,0,0,0,0,9,1,9,0,9,1,9,0,9,1,3,9,0,0])																	
matriz.append([0,0,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,0,0])																	
matriz.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz.append([1,1,3,1,1,1,1,1,1,1,1,1,2,9,0,9,9,9,9,9,9,9,9,9,9,0,9,2,1,1,1,1,1,1,1,1,1,3,1,1])																	
matriz.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz.append([0,0,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,9,0,9,1,9,9,9,9,9,9,0,0])																	
matriz.append([0,0,9,1,1,1,1,1,1,9,0,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,1,9,9,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0])																	
matriz.append([0,0,9,1,9,9,0,0,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,0,0,9,9,1,9,0,0])																	
matriz.append([0,0,9,1,1,9,0,0,9,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,9,0,0])																	
matriz.append([0,0,9,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,0,0,9,1,9,9,0,0])																	
matriz.append([0,0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,0])																	
matriz.append([0,0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,0,0,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0,0])																	
matriz.append([0,0,0,9,2,1,1,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,1,1,3,1,1,1,1,1,1,1,1,2,9,0,0,0])																	
matriz.append([0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0])																	
matriz.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])


# Funcion para dibujar matriz (posible inspector)
def dibujar_matriz(matriz):
    ancho = canvasC2.winfo_reqwidth()
    alto = canvasC2.winfo_reqheight()
    
    # Calcula el ancho y alto de una celda en el canvas
    ancho_celda = ancho // len(matriz[0])
    alto_celda = alto // len(matriz)
    
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            x = (j + 0.5) * ancho_celda  # Centrar el elemento horizontalmente
            y = (i + 0.5) * alto_celda  # Centrar el elemento verticalmente
            valor = str(matriz[i][j])
            if valor=="1":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=verde,tags="matriz_texto")
            elif valor=="2":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=rojo,tags="matriz_texto")
            elif valor=="3":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=amarillo,tags="matriz_texto")
            elif valor=="9":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=gris,tags="matriz_texto")
            else:
                canvasC2.create_text(x, y, text=valor, font=("Arial", 18), fill=azul,tags="matriz_texto")



# Dibujar la matriz en el canvasC2
dibujar_matriz(matriz)

# Imagenes de pacman
pacman_iz = tk.PhotoImage(file="pacman_iz.png").subsample(5, 5)
pacman_de = tk.PhotoImage(file="pacman_de.png").subsample(5, 5)
pacman_ar = tk.PhotoImage(file="pacman_ar.png").subsample(5, 5)
pacman_ab = tk.PhotoImage(file="pacman_ab.png").subsample(5, 5)
pacman_iz2 = tk.PhotoImage(file="pacman_iz2.png").subsample(5, 5)
pacman_de2 = tk.PhotoImage(file="pacman_de2.png").subsample(5, 5)
pacman_ar2 = tk.PhotoImage(file="pacman_ar2.png").subsample(5, 5)
pacman_ab2 = tk.PhotoImage(file="pacman_ab2.png").subsample(5, 5)

#pacman_img = canvasC2.create_image(19*18-5, 20*18-5, anchor=tk.NW, image=pacman_iz,tags="pacman")

# Imagenes de las bolitas

bolita1= tk.PhotoImage(file="bol1.png").subsample(8, 8)
bolita2= tk.PhotoImage(file="bol2.png").subsample(8, 8)
bolita3= tk.PhotoImage(file="bol3.png").subsample(8, 8)
bolita4= tk.PhotoImage(file="bol4.png").subsample(8, 8)
bolota = tk.PhotoImage(file="BOL.png").subsample(15, 15)
cerezas = tk.PhotoImage(file="cerezas.png").subsample(7, 7)
banano = tk.PhotoImage(file="banano.png").subsample(14, 14)
fresa = tk.PhotoImage(file="fresa.png").subsample(9, 9)

lista_bolas = [bolita1,bolita3,bolita4]
lista_frutas = [cerezas,banano,fresa]

cantidad_8 = 1
               
mov_ab = False
mov_ar = False
mov_iz = False
mov_de = False
                 
########################################################################################################################### 
#                                                  INICIA CLASE PACMAN                                                    #
########################################################################################################################### 
class PACMAN:
    def __init__(self,Estado):
        self.Estado = Estado
        self.PosicionX = 337 # (19*18)-5
        self.PosicionY = 355 # (20*18)-5
        self.Velocidad = 1 # velocidad normal
        if Estado=="vivo":
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY, image=pacman_iz,anchor=tk.NW,tags="pacman")
        else:
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY,anchor=tk.NW,tags="pacman")
###########################################################################################################################        
    def Mover_Izquierda(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_ab = False
        mov_de = False
        if not mov_iz and self.Estado=="vivo":
            mov_iz = True
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_iz = False
        mov_ab = False
        if not mov_de and self.Estado=="vivo":
            mov_de = True
            return self.mover_pacman_derecha_aux()
    def mover_pacman_abajo(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ar = False
        mov_iz = False
        mov_de = False
        if not mov_ab and self.Estado=="vivo":
            mov_ab = True
            return self.mover_pacman_abajo_aux()
    def mover_pacman_arriba(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de
        mov_ab = False
        mov_iz = False
        mov_de = False
        if not mov_ar and self.Estado=="vivo":
            mov_ar = True
            return self.mover_pacman_arriba_aux()
########################################################################################################################### 
    def mover_pacman_izquierda_aux(self):
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen,image=pacman_iz, tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX <= 0:
            canvasC2.coords(self.Imagen, 702, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        
        if j.is_integer():
            j = int(j)
        elif (j-int(j)<0.5):
            j=int(j)
        else:
            j=int(j)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (j-int(j/18)>0.5):
            self.PosicionX=(int(j))*18
            canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if not (matriz[int(i)][int(j)-1]!=9):
                mov_iz = False
                return -1
            return self.mover_pacman_izquierda_aux_2(cont)  
        else:
            mov_iz = False
    def mover_pacman_derecha_aux(self):
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX+18>=702:
            canvasC2.coords(self.Imagen, 0, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if j.is_integer():
            j = int(j)
        elif (j-int(j)<0.5):
            j=int(j)
        else:
            j=int(j)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (j-int(j/18)>0.5):
            self.PosicionX=(int(j))*18
            canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if not (matriz[int(i)][int(j)+1]!=9):
                mov_de = False
                return -1
            return self.mover_pacman_derecha_aux_2(cont)  
        else:
            mov_de = False
    def mover_pacman_arriba_aux(self):
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.PosicionY=(int(i))*18
            canvasC2.coords(self.Imagen, self.PosicionX, self.PosicionY-5)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if not (matriz[int(i)-1][int(j)]!=9):
                mov_ar = False
                return -1
            return self.mover_pacman_arriba_aux_2(cont) 
        else:
            mov_ar = False
    def mover_pacman_abajo_aux(self):
        global matriz
        global cantidad_8
        canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+5) / 18)
        j = ((self.PosicionX+5) / 18)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        if (i-int(i/18)>0.5):
            self.PosicionY=(int(i))*18
            canvasC2.coords(self.Imagen, self.PosicionX, self.PosicionY-5)
        if elemento == 1 or elemento == 8 or elemento==3 or elemento==2:
            if elemento==1 or elemento == 2 or elemento==3:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1
            canvasC2.delete("matriz_texto")
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if not (matriz[int(i)+1][int(j)]!=9):
                mov_ab = False
                return -1
            return self.mover_pacman_abajo_aux_2(cont) 
        else:
            mov_ab = False
########################################################################################################################### 
    def mover_pacman_izquierda_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz2,tags="pacman")
            if not mov_de and not mov_ar and not mov_ab:
                canvasC2.move(self.Imagen , -1, 0)
                ventana_nueva.after(6, self.mover_pacman_izquierda_aux_2, cont + 1)
        else:
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_de2,tags="pacman")
            if not mov_iz and not mov_ar and not mov_ab:
                canvasC2.move(self.Imagen, 1, 0)
                ventana_nueva.after(6, self.mover_pacman_derecha_aux_2, cont + 1)
        else:
            return self.mover_pacman_derecha_aux()
    def mover_pacman_arriba_aux_2(self,cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ab:
                canvasC2.move(self.Imagen, 0, -1)
                ventana_nueva.after(6, self.mover_pacman_arriba_aux_2, cont + 1)
        else:
            return self.mover_pacman_arriba_aux()
    def mover_pacman_abajo_aux_2(self, cont):
        if cont < 18:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ar:
                canvasC2.move(self.Imagen, 0, +1)
                ventana_nueva.after(6, self.mover_pacman_abajo_aux_2, cont + 1)
        else:
            return self.mover_pacman_abajo_aux()
###########################################################################################################################
###########################################################################################################################



def asignar_bolas():
    global cantidad_8
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            valor = str(matriz[i][j])
            if valor=="2":
                canvasC2.create_image(j*18, i*18, anchor=tk.NW, image=bolota,tags="bolas")
            elif valor=="3":
                imagen_seleccionada = random.choice(lista_frutas)
                if imagen_seleccionada==fresa:
                    canvasC2.create_image(j*18+2, i*18-4, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")
                else:
                    canvasC2.create_image(j*18-4, i*18-4, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")

            elif valor=="1":
                imagen_seleccionada = random.choice(lista_bolas)
                canvasC2.create_image(j*18+5, i*18+5, anchor=tk.NW, image=imagen_seleccionada,tags="bolas")



        
                
            
                           
asignar_bolas()
canvasC2.tag_lower("rec","bolas") 
pacman = PACMAN("vivo")
            
######################################################################
######################################################################




     







ventana_nueva.bind("<Left>", pacman.Mover_Izquierda)  # Asociar la tecla de flecha izquierda con mover_pacman_izquierda
ventana_nueva.bind("<Right>", pacman.mover_pacman_derecha)  # Asociar la tecla de flecha derecha con mover_pacman_derecha
ventana_nueva.bind("<Up>", pacman.mover_pacman_arriba)  # Asociar la tecla de flecha arriba con mover_pacman_arriba
ventana_nueva.bind("<Down>", pacman.mover_pacman_abajo)  # Asociar la tecla de flecha abajo con mover_pacman_abajo


##########################################################################################


ventana_actual = ventana_principal  # Inicialmente, la ventana actual es la principal

ventana_principal.mainloop()


