import tkinter
import threading
from tkinter import *
import tkinter as tk
from threading import Thread
from tkinter import PhotoImage,NW
from PIL import Image, ImageTk
import pygame as py
from pygame import mixer
import time
import sys
import math
import random
import os
import natsort
from natsort import natsorted

#Inicia mixer para los sonidos
mixer.init()
#Colores
verde="#008F39"
navy = "#2B3467"
celeste = "#99B4D1"
celesteoscuro = "#296d98"
amarillo = "#FCFFE7"
rojo = "#EB455F"
gris = "#b5b5b5"
grisoscuro = "#666666"
azul = "#3E5F8A"
negro = "#000000"
blanco = "#FFFFFF"
azulclaro="#256d7b"
grisoscuro = "#555555"
anaranjado = "#FFA500"

#Fuentes
impact = "Impact"
arial="Arial"
timesnewroman="TimesNewRoman"

#Objeto Juego

#atributos:
#Nivel (int)
#Tablero (matriz)
#Score (lista)
#NumeroDeJuego (int)
#lista_fantasmas (lista)
#lista_colores (lista)
#posiciones_fantasmas (lista)

#metodos:
# ranking(): retorna el High Score
# mostrar(self): muestra los datos del objeto
#IniciarJuego(self): inicia el juego
class Juego:
    def ranking():
        try:  # trata de abrir el domcunento con los puntajes
            file = open('data.txt', 'r')
            read = file.read().split(',')
            global top
            top = natsorted(read, reverse=True)
        except:
            #None
            with open('data.txt', 'w') as file:  # crea el txt de no existir
                file.write(f'{0}: {""},')
                file.close()
    ranking()
    def __init__(self):
        global matriz1
        global top
        self.Nivel = 1
        self.Tablero = matriz1
        self.Score = top[0] #Inicializar con el valor mas alto del data.txt
        self.NumeroDeJuego = 1
        self.lista_fantasmas = []
        self.lista_colores = ["Rojo","Celeste","Rosado","Anaranjado","Rojo","Celeste"]
        self.posiciones_fantasmas = [(294,159),(234,219),(285,219),(339,219),(294,159),(234,219)]

    def mostrar(self):
        print("")
        print("Juego1:")
        print("Tablero: 40x36")
        print("Nivel: " + str(self.Nivel))
        print("Score: "+str(self.Score))
        print("Numero de Juego: "+str(self.NumeroDeJuego))
        print("")

    def IniciarJuego(self):
        global nivelx
        juegos = Label(ventana_nueva, text='Juego #: {}'.format(self.NumeroDeJuego), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
        juegos.place(x=50, y=10)

        score = Label(ventana_nueva, text='Score: {}'.format(self.Score), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
        score.place(x=350, y=10)
        
        canvasC2.delete("matriz_texto")
        nivelx.config(text='Nv {}'.format(self.Nivel))
        global matriz,matriz1, asignar_bolas, paredes, actualizar_cantidad
        matriz=matriz1
        for i in range(len(matriz)):
            for j in range(len(matriz[0])):
                if matriz[i][j]==4:
                    matriz[i][j]= 1
                if matriz[i][j]==5:
                    matriz[i][j]=2
                if matriz[i][j]==6:
                    matriz[i][j]=3
                    
        canvasC2.delete("all")
        paredes()
        actualizar_cantidad()
        asignar_bolas() 
        canvasC2.tag_lower("rec","bolas")
        # Creamos una instancia del objeto PACMAN que representa al jugador
        self.pacman = PACMAN()
        self.pacman.Estado = "vivo"
        
        # Dependiendo del nivel creamos la cantidad de instancias del objeto Ghost
        if self.Nivel == 1:
            self.lista_fantasmas = []
            for i in range (4):
                x,y = self.posiciones_fantasmas[i]
                color = self.lista_colores[i]
                ghost = Ghost("vivo", x, y, color, 1)
                self.lista_fantasmas.append(ghost)
                ghost.name = "ghost"+str(i)
        else:
            self.lista_fantasmas = []
            for i in range (6):
                x,y = self.posiciones_fantasmas[i]
                color = self.lista_colores[i]
                ghost = Ghost("vivo", x, y, color, 1)
                self.lista_fantasmas.append(ghost)
                ghost.name = "ghost"+str(i)
        for fantasma in self.lista_fantasmas:
            if fantasma.color == "Rojo":
                fantasma.Ghost_img = canvasC2.create_image(fantasma.posx, fantasma.posy, anchor=tk.NW, image=RedGhost_iz, tags="RedGhost")
            elif fantasma.color == "Celeste":
                fantasma.Ghost_img = canvasC2.create_image(fantasma.posx, fantasma.posy, anchor=tk.NW, image=BlueGhost_iz, tags="BlueGhost")     
            elif fantasma.color == "Rosado":
                fantasma.Ghost_img = canvasC2.create_image(fantasma.posx, fantasma.posy, anchor=tk.NW, image=PinkGhost_iz, tags="PinkGhost")
            elif fantasma.color == "Anaranjado":
                fantasma.Ghost_img = canvasC2.create_image(fantasma.posx, fantasma.posy, anchor=tk.NW, image=OrangeGhost_iz, tags="OrangeGhost")
        
        ventana_nueva.bind("<Left>", juego1.pacman.Mover_Izquierda)  # Asociar la tecla de flecha izquierda con mover_pacman_izquierda
        ventana_nueva.bind("<Right>", juego1.pacman.mover_pacman_derecha)  # Asociar la tecla de flecha derecha con mover_pacman_derecha
        ventana_nueva.bind("<Up>", juego1.pacman.mover_pacman_arriba)  # Asociar la tecla de flecha arriba con mover_pacman_arriba
        ventana_nueva.bind("<Down>", juego1.pacman.mover_pacman_abajo)  # Asociar la tecla de flecha abajo con mover_pacman_abajo    


# Funcion para mostrar ventanas
def mostrar_ventana(ventana_a_mostrar):
    global ventana_actual
    global animation_running
    animation_running = False 
    stop_animation()
    usuario.delete(0, "end")
    canvasC1.delete("all")
    canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco,tags="texto1")
    ventana_actual.withdraw()  # Oculta la ventana actual
    ventana_a_mostrar.deiconify()  # Muestra la nueva ventana
    ventana_actual = ventana_a_mostrar
    if (ventana_actual.winfo_toplevel().title() == "Ayuda" or ventana_actual.winfo_toplevel().title() == "Acerca de"
        or ventana_actual.winfo_toplevel().title() == "Salon de la fama"):
        animation_running=False
        StopCancionG()
        PlayCancionA()
    if ventana_actual.winfo_toplevel().title() == "Proyecto programado #2":
        animation_running=True
        start_animation(True)
        resetear()
        StopCancionG()
        StopCancionJ()
        StopCancionA()
        PlayCancionG()
    else:
        animation_running = False

#función para cargar imágenes
#E: nombre
#S: imagen respectiva al nombre
def cargarImagen(nombre):
    ruta = os.path.join('imagenes', nombre)  # Define la ubicación de la imagen
    imagen = Image.open(ruta)  # Abre la imagen utilizando PIL
    imagen = imagen.resize((150, 150), Image.BILINEAR)  # Redimensiona la imagen
    foto_tk = ImageTk.PhotoImage(imagen)  # Crea una instancia de PhotoImage con la imagen redimensionada
    return foto_tk


# Crear la ventana principal
ventana_principal = tk.Tk()
ventana_principal.geometry("600x500")
ventana_principal.configure(background="black")
ventana_principal.title("Proyecto programado #2")
canvasC1 = tk.Canvas(ventana_principal, width=500, height=350, borderwidth=0, highlightthickness=0, bg=negro)
canvasC1.place(x=300, y=245, anchor=tk.CENTER)
imagen_titulo = tk.PhotoImage(file="titulo.png")

# Crear una etiqueta con fondo negro y mostrar la imagen
etiqueta = tk.Label(ventana_principal, image=imagen_titulo, bg="black")
etiqueta.place(x=70, y=25)


# Crear la nueva ventana para el juego
ventana_nueva = tk.Toplevel(ventana_principal)
ventana_nueva.geometry("700x650")
ventana_nueva.title("PAC-MAN")
ventana_nueva.configure(background=grisoscuro)
ventana_nueva.withdraw()  # Oculta la ventana nueva al principio
canvasC2 = tk.Canvas(ventana_nueva, width=600, height=540, borderwidth=0, highlightthickness=0, bg=negro)
canvasC2.place(x=350, y=305, anchor=tk.CENTER)

# Funcion para crear paredes
def paredes():
    canvasC2.create_rectangle(0,0, 719/18*15, 647/18*15, fill="blue",tags="rec")
    canvasC2.create_rectangle(36/18*15, 36/18*15, 90/18*15, 270/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 36/18*15, 180/18*15, 90/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(126/18*15, 36/18*15, 180/18*15, 486/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 144/18*15, 144/18*15, 198/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(90/18*15, 216/18*15, 108/18*15, 270/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(0, 288/18*15, 252/18*15, 34/18*152, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 360/18*15, 126/18*15, 414/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 360/18*15, 90/18*15, 558/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(54/18*15, 504/18*15, 108/18*15, 630/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(54/18*15, 576/18*15, 342/18*15, 630/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 432/18*15, 144/18*15, 486/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(36/18*15, 432/18*15, 684/18*15, 486/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(198/18*15, 180/18*15, 254/18*15, 558/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(144/18*15, 504/18*15, 198/18*15, 598/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(378/18*15, 576/18*15, 666/18*15, 630/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(180/18*15, 108/18*15, 594/18*15, 162/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(198/18*15, 180/18*15, 522/18*15, 234/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(234/18*15, 36/18*15, 468/18*15, 90/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(540/18*15, 36/18*15, 684/18*15, 90/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(234/18*15, 90/18*15, 288/18*15, 126/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(324/18*15, 90/18*15, 378/18*15, 126/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(414/18*15, 90/18*15, 468/18*15, 126/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(540/18*15, 36/18*15, 594/18*15, 486/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(630/18*15, 36/18*15, 684/18*15, 270/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(612/18*15, 216/18*15, 684/18*15, 270/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(594/18*15, 144/18*15, 648/18*15, 198/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(234/18*15, 162/18*15, 288/18*15, 198/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(432/18*15, 162/18*15, 486/18*15, 198/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(280/18*15, 230/18*15, 440/18*15, 243/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(270/18*15, 252/18*15, 450/18*15, 324/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(144/18*15, 504/18*15, 576/18*15, 558/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(500/18*15, 288/18*15, 720/18*15, 342/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(594/18*15, 360/18*15, 684/18*15, 414/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(630/18*15, 360/18*15, 684/18*15, 558/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(612/18*15, 504/18*15, 666/18*15, 575/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(468/18*15,180/18*15,522/18*15,530/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(522/18*15, 558/18*15, 576/18*15, 594/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(414/18*15, 558/18*15, 468/18*15, 594/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(252/18*15, 558/18*15, 306/18*15, 594/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(252/18*15, 342/18*15, 468/18*15, 396/18*15, fill="black",tags="rec")
    canvasC2.create_rectangle(324/18*15, 396/18*15, 378/18*15, 450/18*15, fill="black",tags="rec")
    

# Crear la nueva ventana para ayuda
ventana_help = tk.Toplevel(ventana_principal)
ventana_help.geometry("650x450")
ventana_help.title("Ayuda")
ventana_help.configure(background=negro)
ventana_help.withdraw()
canvasC4 = tk.Canvas(ventana_help, width=600, height=400, borderwidth=0, highlightthickness=0, bg=grisoscuro)
canvasC4.place(x=325, y=225, anchor=tk.CENTER)
canvasC4.create_text(300, 50, text="Historia del juego: PacMan es un videojuego arcade creado por el diseñador de\n"+
                                   "videojuegos Toru Iwatani de la empresa Namco, y distribuido por Midway Games\n"+
                                   "al mercado estadounidense a principios de los años 1980.", font=(timesnewroman, 12), fill=blanco)
canvasC4.create_text(300, 130, text="Temática del juego: El juego consiste en conducir a PacMan, una bola amarilla que\n"+
                                    "abre y cierra la boca, por un laberinto (matriz). Suma puntos cuando come aquello\n"+
                                    "que encuentra a su paso, bolitas y diferentes frutas, pero además debe esquivar\n"+
                                    "a los fantasmas.", font=(timesnewroman, 12), fill=blanco)
canvasC4.create_text(300, 280, text="¿Cómo jugar?: El PacMan se mueve solo, por lo tanto el jugador únicamente debe\n"+
                                    "indicar la dirección hacia la cual desea que se dirija el Pac Man, para tal acción,\n"+
                                    "se utilizan las flechitas del teclado:\n\nIzquierada: PacMan irá hacia la"+
                                    " izquiera\n\nDerecha: PacMan irá hacia la derecha\n\nArriba: PacMan irá hacia la arriba\n\n"+
                                    "Abajo: PacMan irá hacia abajo", font=(timesnewroman, 12), fill=blanco)

#se cargan las imagenes de las frutas y las bolitas que se come el pacman
imagen2 = PhotoImage(file="bol1.png").subsample(5,5)
etiqueta2 = tk.Label(ventana_nueva, image=imagen2, bg=grisoscuro)
etiqueta2.place(x=493, y=592)
imagen4 = PhotoImage(file="BOL.png").subsample(13,13)
etiqueta4 = tk.Label(ventana_nueva, image=imagen4, bg=grisoscuro)
etiqueta4.place(x=523, y=590)
imagen5 = PhotoImage(file="banano.png").subsample(12,12)
etiqueta5 = tk.Label(ventana_nueva, image=imagen5, bg=grisoscuro)
etiqueta5.place(x=553, y=585)
imagen6 = PhotoImage(file="fresa.png").subsample(8,8)
etiqueta6 = tk.Label(ventana_nueva, image=imagen6, bg=grisoscuro)
etiqueta6.place(x=594, y=585)
imagen7 = PhotoImage(file="cerezas.png").subsample(7,7)
etiqueta7 = tk.Label(ventana_nueva, image=imagen7, bg=grisoscuro)
etiqueta7.place(x=622, y=585)


# Crear la nueva ventana para salon de la fama
ventana_salon = tk.Toplevel(ventana_principal)
ventana_salon.geometry("450x350")
ventana_salon.title("Salon de la fama")
ventana_salon.configure(background=negro)
ventana_salon.withdraw()
canvasC5 = tk.Canvas(ventana_salon, width=400, height=300, borderwidth=0, highlightthickness=0, bg=grisoscuro)
canvasC5.place(x=225, y=175, anchor=tk.CENTER)
canvasC5.create_text(197, 20, text=" ", font=(timesnewroman, 12), fill=negro)

# Crear la nueva ventana para acerca de
ventana_acerca = tk.Toplevel(ventana_principal)
ventana_acerca.geometry("700x500")
ventana_acerca.title("Acerca de")
ventana_acerca.configure(background=negro)
ventana_acerca.withdraw()
canvasC6 = tk.Canvas(ventana_acerca, width=700, height=500, borderwidth=0, highlightthickness=0, bg=grisoscuro)
canvasC6.place(x=50, y=50)

imagen = cargarImagen("Fabio.png")#Pone la imagen del programador
LabelFondo=Label(ventana_acerca, image=imagen) # etiqueta que va a contener la imagen
LabelFondo.image = imagen  # Mantener una referencia a la imagen
LabelFondo.place (x=150, y=100)# posicion de la imagen
canvasC6.create_text(170,220, text=" Nombre: José Fabio Ruiz Morales", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(170,240, text=" Carné: 2023138210", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(170, 260, text="---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------", font=(timesnewroman, 13), fill=negro)
canvasC6.create_text(350,300, text=" Instituto Tecnológico de Costa Rica", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(350,330, text=" Curso: Introducción a la programación", font=(timesnewroman, 12), fill=blanco)
canvasC6.create_text(350,360, text=" Carrera: Ingeniería en Computadores", font=(timesnewroman, 12), fill=blanco)
canvasC6.create_text(350, 390, text=" Año: 2023", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(350, 420, text=" Profesor: Jeff Schmidt Peralta", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(350, 450, text=" País de producción: Costa Rica", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(350, 480, text=" Versión del programa: 1.0.0", font=(timesnewroman, 13), fill=blanco)

imagen = cargarImagen("Steven.jpg")#Pone la imagen del programador
LabelFondo=Label(ventana_acerca, image=imagen) # etiqueta que va a contener la imagen
LabelFondo.image = imagen  # Mantener una referencia a la imagen
LabelFondo.place (x=500, y=100)# posicion de la imagen
canvasC6.create_text(520,220, text=" Nombre: Steven Solano Zuñiga", font=(timesnewroman, 13), fill=blanco)
canvasC6.create_text(520,240, text=" Carné: 2019077611", font=(timesnewroman, 13), fill=blanco)



# Funcion para iniciar juego con nombre de usuario
#E: nombre de usuario
#S: inicia el juego
#R: el nombre de usuario no puede estar vacío
def comprobar_usuario(entry):
    global nombre_jugador
    nombre_jugador = str(entry.get()).strip()
    jugador = Label(ventana_nueva, text='Jugador : {}'.format(nombre_jugador), bg='black', fg='red', font=('Arial', 12, 'bold'))
    jugador.place(x=50, y=600)
    if not nombre_jugador:
        objetos_texto = canvasC1.find_overlapping(249, 145,249, 145)
        for objeto_id in objetos_texto:
            if canvasC1.type(objeto_id) == "text":
                canvasC1.delete(objeto_id)
        canvasC1.create_text(247, 145, text="Error: Debe ingresar su nombre para continuar", font=("Impact", 13), fill=rojo,tag="texto2")
    else:
        objetos_texto = canvasC1.find_overlapping(247, 145,247, 145)
        for objeto_id in objetos_texto:
            if canvasC1.type(objeto_id) == "text":
                canvasC1.delete(objeto_id)
        canvasC1.delete("texto2")
        mostrar_ventana(ventana_nueva)

global num
num = 0
#Función para el salón de la fama
#crea la ventana y actualiza los datos
#E: el nombre y el puntaje
#S: ordena los nombres de mayor a menor segun puntaje
def ventanax():
    menu = None
    def agarrar_nombre():
        global nombre_jugador
        nombre = nombre_jugador
        global puntos
        print(nombre)
        try:
            with open('data.txt', 'a') as file:  # agrega al txt los datos
                file.write(f'{puntos}-{nombre},')
                file.close()
        except:
            with open('data.txt', 'w') as file:  # crea el txt de no existir
                file.write(f'{puntos}: {nombre},')
    def ventana():
        global menu
        global nombre
        try:
            menu.destroy()
        except:
            None
        nombre = ''
        global num
        while num < 1:
            comprobar_usuario(usuario)
            num += 1
        agarrar_nombre()
        ranking()
        menu.mainloop()
    def ranking():
        try:  # trata de abrir el domcunento con los puntajes y los recrea en la pantalla una tabla de los mejores
            file = open('data.txt', 'r')
            read = file.read().split(',')
            print(read)
            top = natsorted(read, reverse=True)
            print(top)
            puesto1 = Label(canvasC5, text=f'1) {top[0]}', width=15, height=1, font=('Arial Black', 14, 'italic', 'bold'), bg='#1C0C5B', fg='#C996CC')
            puesto1.place(x=100, y=25)
            puesto2 = Label(canvasC5, text=f'2) {top[1]}', width=15, height=2, font=('Arial Black', 14, 'italic', 'bold'), bg='#1C0C5B', fg='#C996CC')
            puesto2.place(x=100, y=100)
            puesto3 = Label(canvasC5, text=f'3) {top[2]}', width=15, height=2, font=('Arial Black', 14, 'italic', 'bold'), bg='#1C0C5B', fg='#C996CC')
            puesto3.place(x=100, y=200)
        except:
            None
        menu.mainloop()
    ventana()


# Funcion para cerrar el juego
def cerrar_aplicacion():
    StopCancionJ()
    StopCancionG()
    ventana_principal.quit()
    ventana_principal.destroy()


canvasC1.create_text(249, 145, text="Ingrese su nombre para comenzar", font=("Impact", 13), fill=blanco) #crea el texto que aparece debajo de la casilla para el nombre

# Calcular el centro de la pantalla
ancho_pantalla = ventana_principal.winfo_screenwidth()
alto_pantalla = ventana_principal.winfo_screenheight()
x_centro = (ancho_pantalla - 700) // 2  # El ancho de la ventana principal es 700
y_centro = (alto_pantalla - 600) // 2   # El alto de la ventana principal es 600

# Establecer la posición de la ventana principal en el centro
ventana_principal.geometry(f"600x500+{x_centro}+{y_centro}")

# Agregar nombre
usuario = tk.Entry(ventana_principal, font=(impact, 12), justify="center")
usuario.pack()
usuario.place(x=303, y=190, anchor=tk.CENTER)

# Botón para abrir una nueva ventana
boton_abrir = tk.Button(ventana_principal, text="Comenzar juego",font=(timesnewroman, 13),fg=blanco, command=lambda: comprobar_usuario(usuario),bg=verde)
boton_abrir.pack()
boton_abrir.place(x=297, y=460, anchor=tk.CENTER)

# Botón para ayuda y regresar 
ayuda = PhotoImage(file="ayuda.png").subsample(3,3)
boton_ayuda = tk.Button(ventana_principal,image=ayuda,font=(timesnewroman, 10),fg=blanco, command=lambda: mostrar_ventana(ventana_help),bg=negro)
boton_ayuda.pack()
boton_ayuda.place(x=533, y=404, anchor=tk.CENTER)

# Botón para salon de la fama
fama = PhotoImage(file="fama.png").subsample(6,6)
boton_fama = tk.Button(ventana_principal,compound="left",image=fama,text="Salon de la fama",font=(timesnewroman, 10),fg=blanco, command=lambda: (mostrar_ventana(ventana_salon), ventanax()),bg=grisoscuro)
boton_fama.pack()
boton_fama.place(x=198, y=350, anchor=tk.CENTER)

# Botón para Acerca de
acerca = PhotoImage(file="acerca.png").subsample(12,12)
boton_acerca = tk.Button(ventana_principal,compound="left",image=acerca,text="  Acerca de ",font=(timesnewroman, 10),fg=blanco, command=lambda: mostrar_ventana(ventana_acerca),bg=grisoscuro)
boton_acerca.pack()
boton_acerca.place(x=420, y=350, anchor=tk.CENTER)

# Botón exit
boton_exit = tk.Button(ventana_principal,text="Salir ",font=(timesnewroman, 10),fg=blanco, command=lambda: cerrar_aplicacion(),bg=rojo)
boton_exit.pack()
boton_exit.place(x=76, y=404, anchor=tk.CENTER)

# Calcular el centro de la pantalla para las nuevas ventanas
x_centro_nueva = (ancho_pantalla - 700) // 2
y_centro_nueva = (alto_pantalla - 650) // 2
x_centro_ayuda = (ancho_pantalla - 650) // 2
y_centro_ayuda = (alto_pantalla - 450) // 2
x_centro_fama = (ancho_pantalla - 450) // 2
y_centro_fama = (alto_pantalla -450) // 2
x_centro_acerca = (ancho_pantalla - 750) // 2
y_centro_acerca = (alto_pantalla - 600) // 2


# Establecer la posición de las ventanas al centro
ventana_nueva.geometry(f"700x650+{x_centro_nueva}+{y_centro_nueva}")
ventana_help.geometry(f"650x450+{x_centro_ayuda}+{y_centro_ayuda}")
ventana_salon.geometry(f"450x350+{x_centro_fama}+{y_centro_fama}")
ventana_acerca.geometry(f"800x600+{x_centro_acerca}+{y_centro_acerca}")

# Botón para regresar a la ventana principal desde la nueva ventana
atras = PhotoImage(file="atras.png").subsample(5, 5)
boton_regresar = tk.Button(ventana_nueva, image=atras, text="",font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=azul)
boton_regresar.pack()
boton_regresar.place(x=25, y=55, anchor=tk.CENTER)


# Botones para regresar a la pantalla inicial
regresar1 = PhotoImage(file="atras.png").subsample(5, 5)
boton_regresar2 = tk.Button(canvasC4, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=verde)
boton_regresar2.pack()
boton_regresar2.place(x=570, y=375, anchor=tk.CENTER)
boton_regresar3 = tk.Button(canvasC5, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=verde)
boton_regresar3.pack()
boton_regresar3.place(x=19, y=282, anchor=tk.CENTER)
boton_regresar4 = tk.Button(canvasC6, image=regresar1,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: mostrar_ventana(ventana_principal), bg=verde)
boton_regresar4.pack()
boton_regresar4.place(x=19, y=19, anchor=tk.CENTER)

# Boton de play
play = PhotoImage(file="play.png").subsample(2,2)
boton_play = tk.Button(ventana_nueva, image=play,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: Comenzar(), bg=verde)
boton_play.pack()
boton_play.place(x=675, y=240, anchor=tk.CENTER)

# Boton de pausa
pause = PhotoImage(file="pausa.png").subsample(2,2)
boton_pause= tk.Button(ventana_nueva, image=pause,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: Pausar(), bg=rojo)
boton_pause.pack()
boton_pause.place(x=675, y=280, anchor=tk.CENTER)

# Boton de reset
reset= PhotoImage(file="reset.png").subsample(10,10)
boton_reset = tk.Button(ventana_nueva, image=reset,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda:resetear(), bg=anaranjado)
boton_reset.pack()
boton_reset.place(x=675, y=320, anchor=tk.CENTER)

# Boton de inspector
lupa= PhotoImage(file="lupa.png").subsample(10,10)
boton_lupa = tk.Button(ventana_nueva, image=lupa,font=(timesnewroman, 13),fg=blanco, compound="left", command=lambda: inspector(), bg=azul)
boton_lupa.pack()
boton_lupa.place(x=675, y=360, anchor=tk.CENTER)

#funcion que resetea el juego
#E: bolas y movimientos
#S: reinicia todo a sus valores iniciales
def resetear():
    global mov_ab,mov_ar,mov_de,mov_iz,cantidad_8,moviendose,Moviendose
    global bolverdes,bolrosas,bolotas,fbananos,ffresas,fcerezas,mov_ghost_iz
    global mov_ghost_ab,mov_ghost_ar,mov_ghost_de,puntos,matriz2,comer_fantasma,pausa
    for i in juego1.lista_fantasmas:
        i.estado = "muerto"
    juego1.pacman.Estado = "muerto"
    if not juego1.Nivel == 2:
        puntos = 0
    pausa = False
    mov_ab = False
    mov_ar = False
    mov_iz = False
    mov_de = False
    cantidad_8 = 1
    moviendose = False
    Moviendose = False
    bolverdes = 0
    bolrosas = 0
    bolotas = 0
    fbananos = 0
    ffresas = 0
    fcerezas = 0
    mov_ghost_iz = False
    mov_ghost_ab = False
    mov_ghost_de = False
    mov_ghost_ar = False
    matriz1=matriz2
    comer_fantasma = False
    StopCancionJ()
    StopCancionG()
    StopCancionP()
    PlayCancionG()
    juego1.NumeroDeJuego += 1
    juego1.IniciarJuego()

reprod = True
musiic = True
pausar = False
pausa = False

#Funcion que da inicio a un juego
#E: Moviendose, moviendose, reprod,pausar,pausa
#S: movimientos hacia arriba, abajo, derecha o izquierda
def Comenzar():
    global Moviendose, moviendose, reprod,pausar,pausa
    Moviendose = True
    global mov_ab, mov_ar, mov_de, mov_iz
    if moviendose=="mov_ab":
        juego1.pacman.mover_pacman_abajo(Event)
    elif moviendose=="mov_ar":
        juego1.pacman.mover_pacman_arriba(Event)
    elif moviendose=="mov_de":
        juego1.pacman.mover_pacman_derecha(Event)
    elif moviendose=="mov_iz":
        juego1.pacman.Mover_Izquierda(Event)
    else:
        juego1.pacman.Mover_Izquierda(Event)
    StopCancionJ()  
    StopCancionG()
    PlayCancionJ()
    reprod = False
    juego1.pacman.Estado = "vivo"
    pausar = False
    if not pausa:
        for i in range(len(juego1.lista_fantasmas)):
            thread_izquierda_ghost = threading.Thread(target=juego1.lista_fantasmas[i].iniciar_mov_fantasma)
            thread_izquierda_ghost.start()
    pausa = False

#Función que inicializa y detiene las canciones
def Comenzar2():
    global reprod, musiic
    musiic = True
    if reprod:
        StopCancionG()
        PlayCancionG()
        StopCancionJ()
    else:
        StopCancionJ()  
        StopCancionG()
        PlayCancionJ()

moviendose = False
Moviendose = False

#funcion que pausa el juego
#E: parametros actuales del juego
#S: pausa el juego
def Pausar():
    global thread_izquierda_ghost
    global mov_ab, mov_ar, mov_de, mov_iz, reprod
    global Moviendose, moviendose,pausar,pausa
    Moviendose=False
    if mov_ab==True:
        moviendose= "mov_ab"
    elif mov_ar==True:
        moviendose = "mov_ar"
    elif mov_iz == True:
        moviendose = "mov_iz"
    elif mov_de == True:
        moviendose = "mov_de"
    StopCancionG()
    PlayCancionG()
    reprod = True
    pausar=True
    StopCancionJ()
    mov_ab =  mov_ar= mov_de = mov_iz = False
    pausa=True

#funcion que detiene las demas canciones
def Pausar2():
    global musiic
    StopCancionG()
    StopCancionJ()
    musiic = False

#Matriz del juego
matriz1=[]
matriz1.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz1.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])																	
matriz1.append([0,0,9,9,9,9,9,9,9,9,0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0,0,9,9,9,9,9,9,9,9,0,0])																	
matriz1.append([0,0,9,2,1,1,1,1,1,9,0,0,0,9,1,1,1,1,1,2,1,1,1,1,1,9,0,0,0,0,9,1,1,1,1,1,2,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,1,9,0,0,0,9,1,9,9,9,9,1,9,9,9,9,1,9,0,0,0,0,9,1,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,9,1,9,0,0,0,0,9,1,9,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,1,9,9,9,9,1,9,9,9,9,9,9,1,9,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,9,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,9,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,1,3,1,1,1,9,0,0,0,9,1,9,0,0,0,0,0,0,0,0,9,1,9,0,0,0,9,1,1,1,1,1,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,1,9,0,9,9,9,1,9,9,9,9,9,9,9,9,9,9,1,9,9,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,9,1,9,0,9,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,1,9,0,9,1,9,0,9,1,9,0,0,0,0,0,9,9,9,0,0,0,0,9,1,9,0,9,1,9,0,9,1,3,9,0,0])																	
matriz1.append([0,0,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,9,9,9,9,0,0])																	
matriz1.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz1.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,9,9,9,9,9,9,9,9,9,9,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz1.append([1,1,3,1,1,1,1,1,1,1,1,1,2,9,0,9,9,9,9,9,9,9,9,9,9,0,9,2,1,1,1,1,1,1,1,1,1,3,1,1])																	
matriz1.append([9,9,9,9,9,9,9,9,1,9,9,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,9,9,1,9,9,9,9,9,9,9,9])																	
matriz1.append([0,0,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,0,9,1,9,0,0,0,0,0,0,0])																	
matriz1.append([0,0,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,9,0,9,1,9,9,9,9,9,9,0,0])																	
matriz1.append([0,0,9,1,1,1,1,1,1,9,0,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,0,9,1,1,1,1,1,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,9,1,9,0,9,1,9,0,0,0,0,9,1,9,0,0,0,0,0,9,1,9,0,9,1,9,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,1,9,9,9,1,9,9,9,9,9,9,1,9,9,9,9,9,9,9,1,9,9,9,1,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,0,0,0,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0])																	
matriz1.append([0,0,9,1,9,9,0,0,9,9,9,9,1,9,9,9,9,9,9,9,9,9,9,9,9,9,9,1,9,9,9,9,0,0,9,9,1,9,0,0])																	
matriz1.append([0,0,9,1,1,9,0,0,9,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,9,0,0])																	
matriz1.append([0,0,9,9,1,9,0,0,9,1,9,9,9,9,9,1,9,9,9,9,9,9,9,9,1,9,9,9,9,9,1,9,0,0,9,1,9,9,0,0])																	
matriz1.append([0,0,0,9,1,9,0,0,9,1,9,0,0,0,9,1,9,0,0,0,0,0,0,9,1,9,0,0,0,9,1,9,0,0,9,1,9,0,0,0])																	
matriz1.append([0,0,0,9,1,9,9,9,9,1,9,9,9,9,9,1,9,9,9,0,0,9,9,9,1,9,9,9,9,9,1,9,9,9,9,1,9,0,0,0])																	
matriz1.append([0,0,0,9,2,1,1,1,1,1,1,1,1,1,1,1,1,1,9,0,0,9,1,1,1,1,3,1,1,1,1,1,1,1,1,2,9,0,0,0])																	
matriz1.append([0,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,9,0,0,0])																	
matriz1.append([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0])
matriz2=matriz1


#Funcion que dibuja la matriz
#E: la matriz
#S: la matriz dibujada en un canvas
def dibujar_matriz(matriz):
    global matriz1
    matriz=matriz1
    ancho = canvasC2.winfo_reqwidth()
    alto = canvasC2.winfo_reqheight()
    # Calcula el ancho y alto de una celda en el canvas
    ancho_celda = ancho // len(matriz[0])
    alto_celda = alto // len(matriz)
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            x = (j + 0.5) * ancho_celda  # Centrar el elemento horizontalmente
            y = (i + 0.5) * alto_celda  # Centrar el elemento verticalmente
            valor = str(matriz[i][j])
            if valor=="1":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 10), fill=verde,tags="matriz_texto")
            elif valor=="2":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 10), fill=rojo,tags="matriz_texto")
            elif valor=="3":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 10), fill=amarillo,tags="matriz_texto")
            elif valor=="9":
                canvasC2.create_text(x, y, text=valor, font=("Arial", 10), fill=gris,tags="matriz_texto")
            else:
                canvasC2.create_text(x, y, text=valor, font=("Arial", 10), fill=blanco,tags="matriz_texto")
    canvasC2.tag_raise("matriz_texto")      


# Imagenes de pacman
pacman_iz = tk.PhotoImage(file="pacman_iz.png").subsample(4, 4)
pacman_de = tk.PhotoImage(file="pacman_de.png").subsample(4, 4)
pacman_ar = tk.PhotoImage(file="pacman_ar.png").subsample(4, 4)
pacman_ab = tk.PhotoImage(file="pacman_ab.png").subsample(4, 4)
pacman_iz2 = tk.PhotoImage(file="pacman_iz2.png").subsample(4, 4)
pacman_de2 = tk.PhotoImage(file="pacman_de2.png").subsample(4, 4)
pacman_ar2 = tk.PhotoImage(file="pacman_ar2.png").subsample(4, 4)
pacman_ab2 = tk.PhotoImage(file="pacman_ab2.png").subsample(4, 4)
pacman_muere1 = tk.PhotoImage(file="muere1.png").subsample(3, 3)
pacman_muere2 = tk.PhotoImage(file="muere2.png").subsample(3, 3)
pacman_muere3 = tk.PhotoImage(file="muere3.png").subsample(3, 3)
pacman_muere4 = tk.PhotoImage(file="muere4.png").subsample(3, 3)
pacman_muere5 = tk.PhotoImage(file="muere5.png").subsample(3, 3)




# Imagenes de las bolitas
bolita1= tk.PhotoImage(file="bol1.png").subsample(9, 9)
bolita2= tk.PhotoImage(file="bol2.png").subsample(9, 9)
bolita3= tk.PhotoImage(file="bol3.png").subsample(9, 9)
bolita4= tk.PhotoImage(file="bol4.png").subsample(9, 9)
bolota = tk.PhotoImage(file="BOL.png").subsample(16, 16)
cerezas = tk.PhotoImage(file="cerezas.png").subsample(8, 8)
banano = tk.PhotoImage(file="banano.png").subsample(15, 15)
fresa = tk.PhotoImage(file="fresa.png").subsample(10, 10)

lista_bolas = [bolita1,bolita3,bolita4]
lista_frutas = [cerezas,banano,fresa]

cantidad_8 = 1

mov_ab = False
mov_ar = False
mov_iz = False
mov_de = False


########################################################################################################################### 
#                                                  INICIA CLASE JUEGO                                                   #
###########################################################################################################################

#funcion que da la posibilidad al pacman de comer fantasmas
#E: estado booleano de comer_fantasma
#S: comer_fantasma = True
comer_fantasma = False
def cambiar_variable():
    global comer_fantasma  
    comer_fantasma = True
    PlayCancionP()
    StopCancionJ()
    ventana_nueva.after(10000,resetear_variable)

#funcion que quita la posibilidad a pacman de comer fantasmas
#E: estado booleano de comer_fantasma
#S: comer_fantasma = True
def resetear_variable():
    global comer_fantasma
    if comer_fantasma==True:
        StopCancionP()
        PlayCancionJ()
        comer_fantasma = False

                 
########################################################################################################################### 
#                                                  INICIA CLASE PACMAN                                                    #
########################################################################################################################### 
puntos = 0
mover = None

#Objeto PACMAN

#atributos:
#Estado (str)
#PosicionX (int)
#PosicionY (int)
#Velocidad (int)

#metodos:
# mostrar(self): muestra los datos del objeto
#Mover_Izquierda(self, event): mueve a pacman a la izquierda
#mover_pacman_derecha(self, event): mueve a pacman a la derecha
#mover_pacman_abajo(self, event): mueve a pacman abajo
#mover_pacman_arriba(self, event): mueve a pacman arriba


class PACMAN:
    def __init__(self):
        self.Estado = "vivo"
        self.PosicionX = 276 # (19*15)-9   277
        self.PosicionY = 291 # (20*15)-9    292
        self.Velocidad = 1 # velocidad normal (segundos)
        self.estaba = None
        if self.Estado=="vivo":
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY, image=pacman_iz,anchor=tk.NW,tags="pacman")
        else:
            self.Imagen = canvasC2.create_image(self.PosicionX, self.PosicionY,anchor=tk.NW,tags="pacman")
        canvasC2.tag_lower("RedGhost","pacman")
    def mostrar(self):
        print("Pacman:")
        print("Estado: "+ str(self.Estado))
        print("Posicion X: " + str(int(self.PosicionX/15)))
        print("Posicion Y: " + str(int(self.PosicionY/15)))
        print("Velocidad: "+ str(self.Velocidad))
        print("")
###########################################################################################################################        
    def Mover_Izquierda(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de,mover
        global Moviendose,matriz
        mover = "izq"
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9)/ 15)
        if not mov_iz and self.Estado=="vivo" and Moviendose == True and matriz[int(i)][int(j)-1]!=9:
            mov_ar = False
            mov_ab = False
            mov_de = False
            mov_iz = True
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de,mover,matriz
        mover = "der"
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9)/ 15)
        if not mov_de and self.Estado=="vivo" and Moviendose == True and matriz[int(i)][int(j)+1]!=9:
            mov_ar = False
            mov_iz = False
            mov_ab = False
            mov_de = True
            return self.mover_pacman_derecha_aux()
    def mover_pacman_abajo(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de,mover,matriz
        mover = "aba"
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9)/ 15)
        if not mov_ab and self.Estado=="vivo" and Moviendose == True and matriz[int(i)+1][int(j)]!=9:
            mov_ar = False
            mov_iz = False
            mov_de = False
            mov_ab = True
            return self.mover_pacman_abajo_aux()
    def mover_pacman_arriba(self, event):
        global mov_ab,mov_ar,mov_iz,mov_de,mover,matriz
        mover = "arr"
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9)/ 15)
        if not mov_ar and self.Estado=="vivo" and Moviendose == True and matriz[int(i)-1][int(j)]!=9:
            mov_ab = False
            mov_iz = False
            mov_de = False
            mov_ar = True
            return self.mover_pacman_arriba_aux()
########################################################################################################################### 
    def mover_pacman_izquierda_aux(self):
        global bolverdes, bolrosas, bolotas, fbananos, ffresas, fcerezas
        global mov_ab, mov_ar, mov_de, mov_iz, reprod, musiic,mover
        global puntos
        global matriz
        global cantidad_8
        matriz=matriz1
        canvasC2.itemconfig(self.Imagen,image=pacman_iz, tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX <= 0:
            canvasC2.coords(self.Imagen, 585, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)   
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9)/ 15)
        elemento = matriz[int(i)][int(j)]
        cont=0
        verificar_nivel(matriz)
        if elemento!=9:
            if elemento==1:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1                                   
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento==1:
                matriz[int(i)][int(j)]=4
                puntos += 10
                bolverdes += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
            if elemento == 2:
                matriz[int(i)][int(j)]=5
                cambiar_variable()
                puntos += 20
                bolotas += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
                for ghost in juego1.lista_fantasmas:
                    canvasC2.itemconfig(ghost.Ghost_img, image=fantasma_azul, tags="RedGhost")
            if elemento== 3:
                matriz[int(i)][int(j)]=6
                puntos += 50
                if (int(i)==9 and int(j)==5) or (int(i)==29 and int(j)==19 ) or (i==17 and int(j)==37 ):
                    ffresas +=1
                elif (int(i)==17 and int(j)==2) or (int(i)==33 and int(j)==26 ) or (int(i)==11 and int(j)== 19):
                    fbananos +=1
                else:
                    fcerezas +=1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-fruit.mp3")
                    mixer.music.play(loops=0)
            actualizar_cantidad()
            a=int((self.PosicionX)/15)
            b=int((self.PosicionY)/15)
            for ghost in juego1.lista_fantasmas:
                c=int(ghost.posx/15)
                d=int(ghost.posy/15)
                if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                    imagen= canvasC2.itemcget(ghost.Ghost_img, "image")
                    if imagen != "pyimage111" and ghost.estado=="vivo":
                        self.Estado="muerto"
                        self.secuencia_muerte(1)
                    elif ghost.estado == "vivo":
                        if musiic:
                            mixer.music.load("sonidos\pacman-eating-ghost.mp3")
                            mixer.music.play(loops=0)
                        ghost.estado = "muerto"
                        canvasC2.delete(ghost.Ghost_img)
                        newghost=Ghost("vivo",234,219,"Celeste",1)
                        newghost.crear_fantasma()
                        thread_izquierda_ghost = threading.Thread(target=newghost.iniciar_mov_fantasma)
                        thread_izquierda_ghost.start()
                        juego1.lista_fantasmas.append(newghost)
                        
                        puntos +=200
            
            if not (matriz[int(i)][int(j)-1]!=9):
                mov_iz = False
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
            if not self.Estado=="muerto" and mov_iz == True:
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
                else:        
                    return self.mover_pacman_izquierda_aux_2(cont)  
        else:
            mov_iz = False
            
    def mover_pacman_derecha_aux(self):
        global bolverdes, bolrosas, bolotas, fbananos, ffresas, fcerezas
        global mov_ab, mov_ar, mov_de, mov_iz, reprod, musiic
        global puntos
        global matriz1
        global cantidad_8
        matriz=matriz1
        canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        if self.PosicionX+15>=585:
            canvasC2.coords(self.Imagen, 0, self.PosicionY)
            self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9) / 15)
        elemento = matriz[int(i)][int(j)]
        cont=0
        verificar_nivel(matriz)
        if elemento!=9:
            if elemento==1:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1                                   
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento==1:
                matriz[int(i)][int(j)]=4
                puntos += 10
                bolverdes += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
            if elemento == 2:
                matriz[int(i)][int(j)]=5
                cambiar_variable()
                puntos += 20
                bolotas += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
                for ghost in juego1.lista_fantasmas:
                    canvasC2.itemconfig(ghost.Ghost_img, image=fantasma_azul, tags="RedGhost")
            if elemento== 3:
                matriz[int(i)][int(j)]=6
                puntos += 50
                if (int(i)==9 and int(j)==5) or (int(i)==29 and int(j)==19 ) or (i==17 and int(j)==37 ):
                    ffresas +=1
                elif (int(i)==17 and int(j)==2) or (int(i)==33 and int(j)==26 ) or (int(i)==11 and int(j)== 19):
                    fbananos +=1
                else:
                    fcerezas +=1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-fruit.mp3")
                    mixer.music.play(loops=0)
            actualizar_cantidad()
            a=int((self.PosicionX)/15)
            b=int((self.PosicionY)/15)
            for ghost in juego1.lista_fantasmas:
                c=int(ghost.posx/15)
                d=int(ghost.posy/15)
                if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                    imagen= canvasC2.itemcget(ghost.Ghost_img, "image")
                    if imagen != "pyimage111" and ghost.estado=="vivo":
                        self.Estado="muerto"
                        self.secuencia_muerte(1)
                    elif ghost.estado == "vivo":
                        if musiic:
                            mixer.music.load("sonidos\pacman-eating-ghost.mp3")
                            mixer.music.play(loops=0)
                        ghost.estado = "muerto"
                        canvasC2.delete(ghost.Ghost_img)
                        newghost=Ghost("vivo",294,159,"Rojo",1)
                        thread_izquierda_ghost = threading.Thread(target=newghost.iniciar_mov_fantasma)
                        thread_izquierda_ghost.start()
                        newghost.crear_fantasma()
                        juego1.lista_fantasmas.append(newghost)
                        puntos +=200
    
            if not (matriz[int(i)][int(j)+1]!=9):
                mov_de = False
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
            if not self.Estado=="muerto" and mov_de == True:
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
                else:
                    return self.mover_pacman_derecha_aux_2(cont)  
        else:
            mov_de = False
    def mover_pacman_arriba_aux(self):
        global bolverdes, bolrosas, bolotas, fbananos, ffresas, fcerezas
        global mov_ab, mov_ar, mov_de, mov_iz, reprod
        global puntos
        global matriz1
        global cantidad_8
        matriz=matriz1
        canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9) / 15)
        elemento = matriz[int(i)][int(j)]
        cont=0
        verificar_nivel(matriz)
        if elemento!=9:
            if elemento==1:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1                                   
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento==1:
                matriz[int(i)][int(j)]=4
                puntos += 10
                bolverdes += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
            if elemento == 2:
                matriz[int(i)][int(j)]=5
                cambiar_variable()
                puntos += 20
                bolotas += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
                for ghost in juego1.lista_fantasmas:
                    canvasC2.itemconfig(ghost.Ghost_img, image=fantasma_azul, tags="RedGhost")
            if elemento== 3:
                matriz[int(i)][int(j)]=6
                puntos += 50
                if (int(i)==9 and int(j)==5) or (int(i)==29 and int(j)==19 ) or (i==17 and int(j)==37 ):
                    ffresas +=1
                elif (int(i)==17 and int(j)==2) or (int(i)==33 and int(j)==26 ) or (int(i)==11 and int(j)== 19):
                    fbananos +=1
                else:
                    fcerezas +=1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-fruit.mp3")
                    mixer.music.play(loops=0)
            actualizar_cantidad()
            a=int((self.PosicionX)/15)
            b=int((self.PosicionY)/15)
            for ghost in juego1.lista_fantasmas:
                c=int(ghost.posx/15)
                d=int(ghost.posy/15)
                if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                    imagen= canvasC2.itemcget(ghost.Ghost_img, "image")
                    if imagen != "pyimage111" and ghost.estado=="vivo":
                        self.Estado="muerto"
                        self.secuencia_muerte(1)
                    elif ghost.estado == "vivo":
                        if musiic:
                            mixer.music.load("sonidos\pacman-eating-ghost.mp3")
                            mixer.music.play(loops=0)
                        ghost.estado = "muerto"
                        canvasC2.delete(ghost.Ghost_img)
                        newghost=Ghost("vivo",339,219,"Naranja",1)
                        newghost.crear_fantasma()
                        thread_izquierda_ghost = threading.Thread(target=newghost.iniciar_mov_fantasma)
                        thread_izquierda_ghost.start()
                        juego1.lista_fantasmas.append(newghost)
                        puntos +=200
            if not (matriz[int(i)-1][int(j)]!=9):
                mov_ar = False
                if mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
            if not self.Estado=="muerto" and mov_ar == True:
                if mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
                elif mover == "aba" and matriz[int(i)+1][int(j)]!=9:
                    return self.mover_pacman_abajo(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
                else:
                    return self.mover_pacman_arriba_aux_2(cont) 
        else:
            mov_ar = False
    def mover_pacman_abajo_aux(self):
        global bolverdes, bolrosas, bolotas, fbananos, ffresas, fcerezas
        global mov_ab, mov_ar, mov_de, mov_iz, reprod
        global ghost1
        global puntos
        global matriz1
        global cantidad_8
        matriz=matriz1
        canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
        self.PosicionX, self.PosicionY = canvasC2.coords(self.Imagen)
        i = ((self.PosicionY+9) / 15)
        j = ((self.PosicionX+9) / 15)
        elemento = matriz[int(i)][int(j)]
        cont=0
        verificar_nivel(matriz)
        if elemento!=9:
            if elemento==1:
                matriz[int(i)][int(j)]=8
                cantidad_8 +=1                                   
            canvasC2.delete("bolas")
            asignar_bolas()
            canvasC2.tag_lower("bolas","pacman")
            if elemento==1:
                matriz[int(i)][int(j)]=4
                puntos += 10
                bolverdes += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
            if elemento == 2:
                matriz[int(i)][int(j)]=5
                cambiar_variable()
                puntos += 20
                bolotas += 1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-food.mp3")
                    mixer.music.play(loops=0)
                for ghost in juego1.lista_fantasmas:
                    canvasC2.itemconfig(ghost.Ghost_img, image=fantasma_azul, tags="RedGhost")
            if elemento== 3:
                matriz[int(i)][int(j)]=6
                puntos += 50
                if (int(i)==9 and int(j)==5) or (int(i)==29 and int(j)==19 ) or (i==17 and int(j)==37 ):
                    ffresas +=1
                elif (int(i)==17 and int(j)==2) or (int(i)==33 and int(j)==26 ) or (int(i)==11 and int(j)== 19):
                    fbananos +=1
                else:
                    fcerezas +=1
                if musiic:
                    mixer.music.load("sonidos\pacman-eating-fruit.mp3")
                    mixer.music.play(loops=0)
            actualizar_cantidad()
            a=int((self.PosicionX)/15)
            b=int((self.PosicionY)/15)
            for ghost in juego1.lista_fantasmas:
                c=int(ghost.posx/15)
                d=int(ghost.posy/15)
                if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
                    imagen= canvasC2.itemcget(ghost.Ghost_img, "image")
                    if imagen != "pyimage111" and ghost.estado=="vivo":
                        self.Estado="muerto"
                        self.secuencia_muerte(1)
                    elif ghost.estado == "vivo":
                        if musiic:
                            mixer.music.load("sonidos\pacman-eating-ghost.mp3")
                            mixer.music.play(loops=0)
                        ghost.estado = "muerto"
                        canvasC2.delete(ghost.Ghost_img)
                        newghost=Ghost("vivo",285,219,"Rosado",1)
                        newghost.crear_fantasma()
                        thread_izquierda_ghost = threading.Thread(target=newghost.iniciar_mov_fantasma)
                        thread_izquierda_ghost.start()
                        juego1.lista_fantasmas.append(newghost)
                        puntos +=200
                    
            if not (matriz[int(i)+1][int(j)]!=9):
                mov_ab = False
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
            if not self.Estado=="muerto" and mov_ab == True:
                if mover == "arr" and matriz[int(i)-1][int(j)]!=9:
                    return self.mover_pacman_arriba(Event)
                elif mover == "der" and matriz[int(i)][int(j)+1]!=9:
                    return self.mover_pacman_derecha(Event)
                elif mover == "izq" and matriz[int(i)][int(j)-1]!=9:
                    return self.Mover_Izquierda(Event)
                else:
                    return self.mover_pacman_abajo_aux_2(cont) 
        else:
            mov_ab = False
#funcion que muestra la animacion cuando pacman muere
#S: las imagenes que animan la muerte del pacman
    def secuencia_muerte(self,cont):
        StopCancionJ()
        canvasC2.coords(self.Imagen, self.PosicionX-5, self.PosicionY-4)
        global pacman_muere1,pacman_muere2,pacman_muere3,pacman_muere4,pacman_muere5
        if cont == 1:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere1, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
            if musiic:
                mixer.music.load("sonidos\perdio.mp3")
                canvasC2.tag_raise("pacman")
            mixer.music.play(loops=0)
        elif cont == 2:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere2, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
            canvasC2.tag_raise("pacman")
        elif cont == 3:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere3, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
            canvasC2.tag_raise("pacman")
        elif cont == 4:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere4, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
            canvasC2.tag_raise("pacman")
        elif cont == 5:
            canvasC2.itemconfig(self.Imagen, image=pacman_muere5, tags="pacman")
            ventana_nueva.after(500, self.secuencia_muerte, cont + 1)
            canvasC2.tag_raise("pacman")
        for i in juego1.lista_fantasmas:
            i.estado =  "muerto"
            canvasC2.tag_raise("pacman")
        
########################################################################################################################### 
    def mover_pacman_izquierda_aux_2(self,cont):
        self.Moviendose = "izquierda"
        if cont < 15:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen , image=pacman_iz2,tags="pacman")
            if not mov_de and not mov_ar and not mov_ab and not self.Estado=="muerto":
                canvasC2.move(self.Imagen , -1, 0)
                ventana_nueva.after(self.Velocidad*6, self.mover_pacman_izquierda_aux_2, cont + 1)
        else:
            return self.mover_pacman_izquierda_aux()
    def mover_pacman_derecha_aux_2(self,cont):
        self.Moviendose = "derecha"
        if cont < 15:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_de,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_de2,tags="pacman")
            if not mov_iz and not mov_ar and not mov_ab and not self.Estado=="muerto":
                canvasC2.move(self.Imagen, 1, 0)
                ventana_nueva.after(self.Velocidad*6, self.mover_pacman_derecha_aux_2, cont + 1)
        else:
            return self.mover_pacman_derecha_aux()
    def mover_pacman_arriba_aux_2(self,cont):
        self.Moviendose = "abajo"
        if cont < 15:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ar2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ab and not self.Estado=="muerto":
                canvasC2.move(self.Imagen, 0, -1)
                ventana_nueva.after(self.Velocidad*6, self.mover_pacman_arriba_aux_2, cont + 1)
        else:
            return self.mover_pacman_arriba_aux()
    def mover_pacman_abajo_aux_2(self, cont):
        self.Moviendose = "arriba"
        if cont < 15:
            if cont >= 10:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab,tags="pacman")
            else:
                canvasC2.itemconfig(self.Imagen, image=pacman_ab2,tags="pacman")
            if not mov_iz and not mov_de and not mov_ar and not self.Estado=="muerto":
                canvasC2.move(self.Imagen, 0, +1)
                ventana_nueva.after(self.Velocidad*6, self.mover_pacman_abajo_aux_2, cont + 1)
        else:
            if self.estaba=="izquierda":
                return self.mover_pacman_izquierda_aux()
            else:    
                return self.mover_pacman_abajo_aux()
        
###########################################################################################################################
###########################################################################################################################

#función que distribuye las bolas en el laberinto (matriz)
#S: las bolitas en distintos puntos del  laberinto
def asignar_bolas():
    global matriz1
    matriz=matriz1
    global cantidad_8
    for i in range(len(matriz)):
        for j in range(len(matriz[0])):
            valor = str(matriz[i][j])
            if valor=="2":
                canvasC2.create_image(j*15, i*15, anchor=tk.NW, image=bolota,tags="bolas")
            elif valor=="3":
                if (i==9 and j==5) or (i==29 and j==19 ) or (i==17 and j==37 ):
                    canvasC2.create_image(j*15+2, i*15-4, anchor=tk.NW, image=fresa,tags="bolas")
                elif (i==17 and j==2) or (i==33 and j==26 ) or (i==11 and j== 19):
                    canvasC2.create_image(j*15-4, i*15-4, anchor=tk.NW, image=banano,tags="bolas")
                else:
                    canvasC2.create_image(j*15-4, i*15-4, anchor=tk.NW, image=cerezas,tags="bolas")

            elif valor=="1":
                canvasC2.create_rectangle(j*15+5, i*15+5, j*15+10,i*15+10, fill="white",tags="bolas")

#función que verifica el nivel
#E: matriz
#S: nivel actual del juego
def verificar_nivel(matriz):
    global bolverdes,ffresas,fcerezas,fbananos,bolotas
    existe = False
    if bolverdes >=60 and bolotas>=1 and fbananos>=1 and ffresas>=1 and fcerezas>=1:
        existe=True
        
    if existe:
        if juego1.Nivel == 1:
            for ghost in juego1.lista_fantasmas:
                ghost.estado = "muerto"
            juego1.pacman.Estado = "muerto"
            StopCancionG()
            StopCancionJ()
            mixer.music.load("sonidos\\nivel2.mp3")
            mixer.music.play(loops=0)
            time.sleep(10)
            juego1.Nivel = 2
            resetear()
        elif juego1.Nivel == 2:
            for ghost in juego1.lista_fantasmas:
                ghost.estado = "muerto"
            juego1.pacman.Estado = "muerto"
            StopCancionG()
            StopCancionJ()
            mixer.music.load("sonidos\\nivel.mp3")
            mixer.music.play(loops=0)
            time.sleep(10)
        
            juego1.Nivel = 1
            resetear()
        
            


#actualizar_cantidad: Función que muestra la cantidad de puntos en la pantalla de juego
#E: global puntos
#S: la cantidad de puntos
#R: puntos debe ser un entero
def actualizar_cantidad():
    global puntos
    global bolverdes
    global nivel
    bverdes.config(text="x"+str(bolverdes))
    bolotass.config(text="x"+str(bolotas))
    fbanano.config(text="x"+str(fbananos))
    ffresa.config(text="x"+str(ffresas))
    fcerezaa.config(text="x"+str(fcerezas))
    cantidad.config(text='Puntos : {}'.format(puntos))


#funcion que muestra la matriz en el laberinto y los datos en la consola (es el inspector)
#S: la matriz actual y los datos de los fantasmas
abierto = False
def inspector():
    global matriz1,abierto
    matriz=matriz1
    Pausar()
    if abierto==False:
        dibujar_matriz(matriz)
        juego1.mostrar()
        juego1.pacman.mostrar()
        i=1
        for ghost in juego1.lista_fantasmas:
            print("Fantasma"+str(i)+":")
            ghost.mostrar()
            print("")
            i +=1
        abierto=True
    else:
        ocultar_matriz()
        abierto=False

#función que deja de mostrar la matriz en el laberinto
def ocultar_matriz():
    canvasC2.delete("matriz_texto")

# Crear una etiqueta para mostrar la cantidad de puntos
cantidad = Label(ventana_nueva, text='Puntos : {}'.format(puntos), bg='black', fg='red', font=('Arial', 12, 'bold'))
cantidad.place(x=245, y=600)

bolverdes = 0
bverdes = Label(ventana_nueva, text="x"+str(bolverdes), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
bverdes.place(x=490, y=615)
bolotas = 0
bolotass = Label(ventana_nueva, text="x"+str(bolotas), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
bolotass.place(x=525, y=615)
fbananos = 0
fbanano = Label(ventana_nueva, text="x"+str(fbananos), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
fbanano.place(x=560, y=615)
ffresas = 0
ffresa = Label(ventana_nueva, text="x"+str(ffresas), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
ffresa.place(x=595, y=615)
fcerezas = 0
fcerezaa = Label(ventana_nueva, text="x"+str(fcerezas), bg=grisoscuro, fg='white', font=('Arial', 10, 'bold'))
fcerezaa.place(x=630, y=615)


sonido_fondo = py.mixer.Sound("sonidos\cancionfondo.mp3")
sonido_fondo_juego = py.mixer.Sound("sonidos\pacman-siren.mp3")
sonido_acercade = py.mixer.Sound("sonidos\cerca_de.mp3")
sonido_ayuda=py.mixer.Sound("sonidos\cerca_de.mp3")
sonido_comiendo_fantasmas = py.mixer.Sound("sonidos\comer-fantasmas.mp3")

def PlayCancionG():  # funcion para reproducir la cancion
    return py.mixer.Sound.play(sonido_fondo, -1)  # Con -1 se indica que se reproduzca la cancion indefinidamente

def PlayCancionJ():  # funcion para reproducir la cancion
    return py.mixer.Sound.play(sonido_fondo_juego, -1)

def PlayCancionA():
    return py.mixer.Sound.play(sonido_ayuda,-1)
PlayCancionG()

def PlayCancionP():  # funcion para reproducir la cancion
    return py.mixer.Sound.play(sonido_comiendo_fantasmas, -1)

# se carga el sonido indicando la ruta
def StopCancionG():  # funcion para pausar la cancion
    py.mixer.Sound.stop(sonido_fondo)

def StopCancionJ():  # funcion para pausar la cancion
    py.mixer.Sound.stop(sonido_fondo_juego)

def StopCancionA():  # funcion para pausar la cancion
    py.mixer.Sound.stop(sonido_ayuda)

def StopCancionP():  # funcion para pausar la cancion
    py.mixer.Sound.stop(sonido_comiendo_fantasmas)

music= tk.PhotoImage(file="music.png").subsample(3, 3)
no_music = tk.PhotoImage(file="no_music.png").subsample(3, 3)

playG = Button(ventana_nueva, image=music, bg="green", fg="black", command=lambda: Comenzar2())  # boton de reproducir la cancion
playG.place(x=660, y=35)
stopG = Button(ventana_nueva, image=no_music, bg="red", fg="black", command=lambda: Pausar2())  # boton de detener la cancion
stopG.place(x=660, y=70)


#imagenes de fantasmas
RedGhost_iz = tk.PhotoImage(file="fantasma_r_iz.png").subsample(5, 5)
RedGhost_de = tk.PhotoImage(file="fantasma_r_de.png").subsample(5, 5)
RedGhost_ar = tk.PhotoImage(file="fantasma_r_ar.png").subsample(5, 5)
RedGhost_ab = tk.PhotoImage(file="fantasma_r_ab.png").subsample(5, 5)


BlueGhost_iz = tk.PhotoImage(file="fantasma_c_iz.png").subsample(5, 5)
BlueGhost_de = tk.PhotoImage(file="fantasma_c_de.png").subsample(5, 5)
BlueGhost_ar = tk.PhotoImage(file="fantasma_c_ar.png").subsample(5, 5)
BlueGhost_ab = tk.PhotoImage(file="fantasma_c_ab.png").subsample(5, 5)

PinkGhost_iz = tk.PhotoImage(file="fantasma_p_iz.png").subsample(5, 5)
PinkGhost_de = tk.PhotoImage(file="fantasma_p_de.png").subsample(5, 5)
PinkGhost_ar = tk.PhotoImage(file="fantasma_p_ar.png").subsample(5, 5)
PinkGhost_ab = tk.PhotoImage(file="fantasma_p_ab.png").subsample(5, 5)

OrangeGhost_iz = tk.PhotoImage(file="fantasma_a_iz.png").subsample(5, 5)
OrangeGhost_de = tk.PhotoImage(file="fantasma_a_de.png").subsample(5, 5)
OrangeGhost_ar = tk.PhotoImage(file="fantasma_a_ar.png").subsample(5, 5)
OrangeGhost_ab = tk.PhotoImage(file="fantasma_a_ab.png").subsample(5, 5)

fantasma_azul=tk.PhotoImage(file="fantasma_azul.png").subsample(10, 10)

#función que muestra la animación de la pantalla principal
#E: camvasC1
#S: la animación de los fantasmitas y el pacman
def animacion_inicial(canvasC1):
    global animation_running
    RedGhost_img1 = canvasC1.create_image(100, 190, anchor=tk.NW, image=RedGhost_iz, tags="RedGhost_inicio")
    BlueGhost_img1 = canvasC1.create_image(150, 190, anchor=tk.NW, image=BlueGhost_iz, tags="BlueGhost_inicio")
    PinkGhost_img = canvasC1.create_image(200, 190, anchor=tk.NW, image=PinkGhost_iz, tags="PinkGhost_inicio")
    OrangeGhost_img = canvasC1.create_image(250, 190, anchor=tk.NW, image=OrangeGhost_iz, tags="OrangeGhost_inicio")
    RedGhost_img2 = canvasC1.create_image(300, 190, anchor=tk.NW, image=RedGhost_iz, tags="RedGhost_inicio")
    BlueGhost_img2 = canvasC1.create_image(350, 190, anchor=tk.NW, image=BlueGhost_iz, tags="BlueGhost_inicio")
    pac_img = canvasC1.create_image(425, 187, anchor=tk.NW, image=pacman_iz, tags="pacman_inicio")
    def move_red_ghost1():
        if animation_running:
            x, y = canvasC1.coords(RedGhost_img1)
            if x > 60:
                canvasC1.move(RedGhost_img1, -1, 0)
            else:
                canvasC1.coords(RedGhost_img1, 440, 190)
            canvasC1.after(30, move_red_ghost1)
    def move_pink_ghost1():
        if animation_running:
            x, y = canvasC1.coords(PinkGhost_img)
            if x > 60:
                canvasC1.move(PinkGhost_img, -1, 0)
            else:

                canvasC1.coords(PinkGhost_img, 440, 190)
            canvasC1.after(30, move_pink_ghost1)
    def move_orange_ghost1():
        if animation_running:
            x, y = canvasC1.coords(OrangeGhost_img)
            if x >60:
                canvasC1.move(OrangeGhost_img, -1, 0)
            else:
                canvasC1.coords(OrangeGhost_img, 440, 190)
            canvasC1.after(30, move_orange_ghost1)
    def move_pac(x_position):
        if animation_running:
            x, y = canvasC1.coords(pac_img)
            
            if x > 60:
                canvasC1.move(pac_img, -1, 0)
                x_position += 1

                # Cambia la imagen de pacman cada 10 unidades
                if x_position % 20 == 0:
                    canvasC1.itemconfig(pac_img, image=pacman_iz2)
                if x_position % 40 == 0:
                    canvasC1.itemconfig(pac_img, image=pacman_iz)
            else:
                canvasC1.coords(pac_img, 440, 190)
            canvasC1.after(30, move_pac, x_position)
    def move_blue_ghost1():
        if animation_running:
            x, y = canvasC1.coords(BlueGhost_img1)
            if x > 60:
                canvasC1.move(BlueGhost_img1, -1, 0)
            else:
                canvasC1.coords(BlueGhost_img1, 440, 190)
            canvasC1.after(30, move_blue_ghost1)
    def move_blue_ghost2():
        if animation_running:
            x, y = canvasC1.coords(BlueGhost_img2)
            if x > 60:
                canvasC1.move(BlueGhost_img2, -1, 0)
            else:
                canvasC1.coords(BlueGhost_img2, 440, 190)
            canvasC1.after(30, move_blue_ghost2)
    def move_red_ghost2():
        if animation_running:
            x, y = canvasC1.coords(RedGhost_img2)
            if x > 60:
                canvasC1.move(RedGhost_img2, -1, 0)
            else:
                canvasC1.coords(RedGhost_img2, 440, 190)
            canvasC1.after(30, move_red_ghost2)
    move_pac(0)
    move_blue_ghost1()
    move_blue_ghost2()
    move_red_ghost1()
    move_pink_ghost1()
    move_orange_ghost1()
    move_red_ghost2()

#inicia la animación
def start_animation(valor):
    global animation_thread
    animation_thread = threading.Thread(target=animacion_inicial, args=(canvasC1,))
    animation_thread.daemon = True
    if valor==True:
        animation_thread.start()# El hilo se detendrá cuando el programa principal se cierre

animation_running=True
start_animation(True)

#función que detiene la animación
def stop_animation():
    global animation_thread
    if animation_thread and animation_thread.is_alive():
        animation_thread.join()
######################################################################
######################################################################

#Objeto Ghost

#atributos:
#estado
#posx
#posy
#color
#velocidad

#métodos:
#mostrar(self): muestra los datos del objeto
#Mover_Izquierda(self, event): mueve a Ghost a la izquierda
#mover_pacman_derecha(self, event): mueve a Ghost a la derecha
#mover_pacman_abajo(self, event): mueve a Ghost abajo
#mover_pacman_arriba(self, event): mueve a Ghost arriba
#opciones(self,i,j,lista): selecciona de manera aleatoria hacia donde se mueve Ghost

class Ghost:
    def __init__(self,estado, posx, posy, color, velocidad):
        self.estado = estado
        self.posx = posx
        self.posy = posy
        self.color = color
        self.velocidad = velocidad
        self.mov_ghost_ab = False
        self.mov_ghost_ar = False
        self.mov_ghost_de = False
        self.mov_ghost_iz = False
    def mostrar(self):
        print("Estado: "+self.estado)
        print("Posicion X: "+str(int(self.posx/15)))
        print("Posicion Y: "+str(int(self.posy/15)))
        print("Color: "+self.color)
        print("Velocidad: "+str(self.velocidad))
###########################################################################################################################
    def mover_Ghost_izquierda(self):
        self.mov_ghost_ar = False
        self.mov_ghost_ab = False
        self.mov_ghost_de = False
        if not self.mov_ghost_iz and not self.estado=="muerto":
            self.mov_ghost_iz = True
            return self.mover_Ghost_izquierda_aux()
    def mover_Ghost_derecha(self):
        self.mov_ghost_ar = False
        self.mov_ghost_ab = False
        self.mov_ghost_iz = False
        if not self.mov_ghost_de and not self.estado=="muerto":
            self.mov_ghost_de = True
            return self.mover_Ghost_derecha_aux()
    def mover_Ghost_abajo(self):
        self.mov_ghost_ar = False
        self.mov_ghost_iz = False
        self.mov_ghost_de = False
        if not self.mov_ghost_ab and not self.estado=="muerto":
            self.mov_ghost_ab = True
            return self.mover_Ghost_abajo_aux()
    def mover_Ghost_arriba(self):
        self.mov_ghost_ab = False
        self.mov_ghost_iz = False
        self.mov_ghost_de = False
        if not self.mov_ghost_ar and not self.estado=="muerto":
            self.mov_ghost_ar = True
            return self.mover_Ghost_arriba_aux()
###########################################################################################################################
    def opciones(self,i,j,lista):
        global matriz1
        matriz=matriz1
        arriba = abajo = izquierda = derecha = False
        if matriz[i-1][j]!=9:
            arriba=True
            self.mov_ghost_ar=False
            lista.append("arriba")
        if matriz[i+1][j]!=9:
            abajo=True
            self.mov_ghost_ab=False
            lista.append("abajo")
        if matriz[i][j+1]!=9:
            derecha=True
            self.mov_ghost_de=False
            lista.append("derecha")
        if matriz[i][j-1]!=9:
            izquierda = True
            self.mov_ghost_iz=False
            lista.append("izquierda")
        direccion = random.choice(lista)
        return direccion
###########################################################################################################################        
    def mover_Ghost_izquierda_aux(self):
        global matriz1,comer_fantasma
        matriz=matriz1
        if self.color == "Rojo" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_iz, tags="RedGhost")
        elif self.color == "Celeste" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_iz, tags="RedGhost")     
        elif self.color == "Rosado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_iz, tags="RedGhost")
        elif self.color == "Anaranjado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_iz, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        if self.posx <= 0:
            canvasC2.coords(self.Ghost_img, 580, self.posy)
            self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy + 6) / 15)
        j = ((self.posx + 6) / 15)
        elemento = matriz[int(i)][int(j)]
        cont = 0
        a=int((juego1.pacman.PosicionX)/15)
        b=int((juego1.pacman.PosicionY)/15)
        c=int(self.posx/15)
        d=int(self.posy/15)
        if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
            imagen= canvasC2.itemcget(self.Ghost_img, "image")
            if imagen != "pyimage111" and self.estado=="vivo":
                juego1.pacman.Estado="muerto"
                juego1.pacman.secuencia_muerte(1)     
        if elemento !=9:
            opciones=[]
            if (matriz[int(i-1)][int(j)]!=9):
                opciones.append("arriba")
            if (matriz[int(i+1)][int(j)]!=9):
                opciones.append("abajo")
            if (matriz[int(i)][int(j) - 1] == 9):
                self.mov_ghost_iz = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("izquierda")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            self.mov_ghost_iz = False
            
    def mover_Ghost_derecha_aux(self):
        global matriz1,comer_fantasma
        matriz=matriz1
        if self.color == "Rojo" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_de, tags="RedGhost")
        elif self.color == "Celeste" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_de, tags="RedGhost")     
        elif self.color == "Rosado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_de, tags="RedGhost")
        elif self.color == "Anaranjado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_de, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        if self.posx +15>=585:
            canvasC2.coords(self.Ghost_img, -6, self.posy)
            self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy + 6) / 15)
        j = ((self.posx + 6) / 15)
        elemento = matriz[int(i)][int(j)]
        cont = 0
        a=int((juego1.pacman.PosicionX)/15)
        b=int((juego1.pacman.PosicionY)/15)
        c=int(self.posx/15)
        d=int(self.posy/15)
        if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
            imagen= canvasC2.itemcget(self.Ghost_img, "image")
            if imagen != "pyimage111" and self.estado=="vivo":
                juego1.pacman.Estado="muerto"
                juego1.pacman.secuencia_muerte(1)
        if elemento !=9:
            opciones=[]
            if (matriz[int(i-1)][int(j)]!=9):
                opciones.append("arriba")
            if (matriz[int(i+1)][int(j)]!=9):
                opciones.append("abajo")
            if (matriz[int(i)][int(j) + 1] == 9):
                self.mov_ghost_de = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("derecha")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            self.mov_ghost_de = False
    def mover_Ghost_abajo_aux(self):
        global matriz1,comer_fantasma
        matriz=matriz1
        if self.color == "Rojo" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_ab, tags="RedGhost")
        elif self.color == "Celeste" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_ab, tags="RedGhost")     
        elif self.color == "Rosado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_ab, tags="RedGhost")
        elif self.color == "Anaranjado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_ab, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy+6) / 15)
        j = ((self.posx+6) / 15)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        a=int((juego1.pacman.PosicionX)/15)
        b=int((juego1.pacman.PosicionY)/15)
        c=int(self.posx/15)
        d=int(self.posy/15)
        if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
            imagen= canvasC2.itemcget(self.Ghost_img, "image")
            if imagen != "pyimage111" and self.estado=="vivo":
                juego1.pacman.Estado="muerto"
                juego1.pacman.secuencia_muerte(1)
        if (i-int(i/15)>0.5):
            self.posy=(int(i))*15
            canvasC2.coords(self.Ghost_img, self.posx, self.posy-6)
        if elemento !=9:
            opciones=[]
            if (matriz[int(i)][int(j-1)]!=9):
                opciones.append("izquierda")
            if (matriz[int(i)][int(j+1)]!=9):
                opciones.append("derecha")
            if (matriz[int(i)+1][int(j)] == 9):
                self.mov_ghost_ab = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("abajo")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            self.mov_ghost_ab = False
    def mover_Ghost_arriba_aux(self):
        global matriz1,comer_fantasma
        matriz=matriz1
        if self.color == "Rojo" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=RedGhost_ar, tags="RedGhost")
        elif self.color == "Celeste" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=BlueGhost_ar, tags="RedGhost")     
        elif self.color == "Rosado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=PinkGhost_ar, tags="RedGhost")
        elif self.color == "Anaranjado" and not comer_fantasma:
            canvasC2.itemconfig(self.Ghost_img, image=OrangeGhost_ar, tags="RedGhost")
        self.posx, self.posy = canvasC2.coords(self.Ghost_img)
        i = ((self.posy+6) / 15)
        j = ((self.posx+6) / 15)
        if i.is_integer():
            i = int(i)
        elif (i-int(i)<0.5):
            i=int(i)
        else:
            i=int(i)+1
        elemento = matriz[int(i)][int(j)]
        cont=0
        a=int((juego1.pacman.PosicionX)/15)
        b=int((juego1.pacman.PosicionY)/15)
        c=int(self.posx/15)
        d=int(self.posy/15)
        if (a == c or a+1 == c or a-1==c ) and (b == d or b+1==d or b-1==d) :
            imagen= canvasC2.itemcget(self.Ghost_img, "image")
            if imagen != "pyimage111" and self.estado=="vivo":
                juego1.pacman.Estado="muerto"
                juego1.pacman.secuencia_muerte(1)
        if (i-int(i/15)>0.5):
            self.posy=(int(i))*15
            canvasC2.coords(self.Ghost_img, self.posx, self.posy-6)
        if elemento !=9:
            opciones=[]
            if (matriz[int(i)][int(j-1)]!=9 ):
                opciones.append("izquierda")
            if (matriz[int(i)][int(j+1)]!=9):
                opciones.append("derecha")
            if (matriz[int(i)-1][int(j)] == 9):
                self.mov_ghost_ar = False
                lista_opciones = []
                direccion = self.opciones(int(i), int(j), lista_opciones)
                funcion = getattr(self, f'mover_Ghost_{direccion}')
                try:
                    ventana_nueva.after(0, funcion)
                except Exception as e:
                    print("hay un error")
            else:
                opciones.append("arriba")
                opcion=random.choice(opciones)
                funcion = getattr(self, f'mover_Ghost_{opcion}_aux_2')
                ventana_nueva.after(6, funcion,cont)
        else:
            self.mov_ghost_ar = False
    
    

            
###########################################################################################################################
    def mover_Ghost_izquierda_aux_2(self, cont):
        global pausar
        if cont < 15 and not self.estado=="muerto" and not pausar:
            #semovia = izquierda
            canvasC2.move(self.Ghost_img, -1, 0)
            ventana_nueva.after(6, self.mover_Ghost_izquierda_aux_2, cont + 1)
        elif self.estado == "vivo":
            return self.mover_Ghost_izquierda_aux()
        
    def mover_Ghost_derecha_aux_2(self, cont):
        global pausar
        if cont < 15 and not self.estado=="muerto" and not pausar:
            canvasC2.move(self.Ghost_img, +1, 0)
            ventana_nueva.after(6, self.mover_Ghost_derecha_aux_2, cont + 1)
        elif self.estado == "vivo":
            return self.mover_Ghost_derecha_aux()

    def mover_Ghost_abajo_aux_2(self, cont):
        global pausar
        if cont < 15 and not self.estado=="muerto" and not pausar:
            canvasC2.move(self.Ghost_img, 0, +1)
            ventana_nueva.after(6, self.mover_Ghost_abajo_aux_2, cont + 1)
        elif self.estado == "vivo":
            return self.mover_Ghost_abajo_aux()

    def mover_Ghost_arriba_aux_2(self, cont):
        global pausar
        if cont < 15 and not self.estado=="muerto" and not pausar:
            canvasC2.move(self.Ghost_img, 0, -1)
            ventana_nueva.after(6, self.mover_Ghost_arriba_aux_2, cont + 1)
        elif self.estado == "vivo":
            return self.mover_Ghost_arriba_aux()
    
###########################################################################################################################
#funcion que crea los fantasmas
#S: fantasmas rojo, celeste, rosado y naranja
    def crear_fantasma(self):
        if self.color == "Rojo":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=RedGhost_iz, tags="RedGhost")
        elif self.color == "Celeste":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=BlueGhost_iz, tags="BlueGhost")     
        elif self.color == "Rosado":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=PinkGhost_iz, tags="PinkGhost")
        elif self.color == "Naranja":
            self.Ghost_img = canvasC2.create_image(self.posx, self.posy, anchor=tk.NW, image=OrangeGhost_iz, tags="OrangeGhost")

#funcion que inicia el movimiento de los fantasmas
#S: inicia el movimiento de los fantasmas en una secuencia
    def iniciar_mov_fantasma(self):
        if self.color == "Rojo" and self.estado=="vivo":
            tiempo_espera = 1
        elif self.color == "Celeste" and self.estado=="vivo":
            tiempo_espera = 6
        elif self.color == "Rosado" and self.estado=="vivo":
            tiempo_espera = 9  
        elif (self.color=="Anaranjado" or self.color=="Naranja") and self.estado=="vivo":
            tiempo_espera = 3
        time.sleep(tiempo_espera)
        if self.color=="Celeste" and self.estado=="vivo":
            canvasC2.coords(self.Ghost_img, 234,159)
        if self.color=="Rosado" and self.estado=="vivo":
            canvasC2.coords(self.Ghost_img, 280,159)
        if (self.color=="Anaranjado" or self.color=="Naranja") and self.estado=="vivo":
            canvasC2.coords(self.Ghost_img, 339,159)
        self.movimiento_thread = Thread(target=self.mover_Ghost_izquierda)
        self.movimiento_thread.start()
#muestra el nivel actual del juego
nivelx = Label(ventana_nueva, text='Nv {}'.format("1"), bg=grisoscuro, fg='orange', font=('Arial', 14, 'bold'))
nivelx.place(x=395, y=597)

juego1 = Juego()
juego1.IniciarJuego()


ventana_nueva.bind("<Left>", juego1.pacman.Mover_Izquierda)  # Asociar la tecla de flecha izquierda con mover_pacman_izquierda
ventana_nueva.bind("<Right>", juego1.pacman.mover_pacman_derecha)  # Asociar la tecla de flecha derecha con mover_pacman_derecha
ventana_nueva.bind("<Up>", juego1.pacman.mover_pacman_arriba)  # Asociar la tecla de flecha arriba con mover_pacman_arriba
ventana_nueva.bind("<Down>", juego1.pacman.mover_pacman_abajo)  # Asociar la tecla de flecha abajo con mover_pacman_abajo

mov_ghost_iz = False
mov_ghost_ab = False
mov_ghost_de = False
mov_ghost_ar = False
##########################################################################################
ventana_actual = ventana_principal  # Inicialmente, la ventana actual es la principal

ventana_principal.mainloop()
#Si llegó hasta aquí, muchas gracias por leer :)